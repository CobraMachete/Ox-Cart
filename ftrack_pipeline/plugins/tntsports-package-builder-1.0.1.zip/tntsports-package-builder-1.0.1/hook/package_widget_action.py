# :coding: utf-8
# :copyright: Copyright (c) 2024 ftrack

import logging
import ftrack_api
from ftrack_action_handler.action import BaseAction


class PackageWidgetAction(BaseAction):

    identifier = 'tntsports.package.builder.action'
    label = 'Show Package Creator'
    description = 'Show Package Creator and Builder'
    icon = 'https://cobramachete.github.io/ftrack_icons/img/package_builder_icon.png'

    def discover(self, session, entities, event):

        user_id = event['source'].get('user', {}).get('username', None)
        currusername = session.api_user
        self.logger.info(user_id)
        self.logger.info(currusername)

        if user_id == currusername:
            # RETURN ACTION CONFIG IF ON A PROJECT OBJECT
            data = event['data']
            self.logger.info('Got selection: {0}'.format(data))

            # EVALUATING SELECTION
            selection = data.get('selection', [])
            
            if len(selection) == 1:
                self.logger.info(selection)
                entity_id = selection[0]['entityId']
                try:
                    entity = session.get('TypedContext', entity_id)
                    self.logger.info(f"Found TypedContext Entity: {entity}")
                    if entity and entity['object_type']['name'] in ('Property'):
                        return True
                except Exception as e:
                    self.logger.warning(f"Error fetching entity: {e}")
        
    
    def launch(self, session, entities, event):
        """
        Method that responds to messages to launch the action.

        This will simply just return a web widget with the specified URL.
        """
        return {
            'success': True,
            'message': 'success', # Required
            'type': 'widget',
            'url': 'https://cobramachete.github.io/Rubicon/',
            'title': 'Show Package Creator',
            'width': 1200,
            'height': 600

        }


def register(session, **kw):
    '''Register plugin.'''
    if not isinstance(session, ftrack_api.Session):
        return

    action = PackageWidgetAction(session)
    action.register()


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    session = ftrack_api.Session(auto_connect_event_hub=True)
    register(session)

    session.event_hub.wait()



