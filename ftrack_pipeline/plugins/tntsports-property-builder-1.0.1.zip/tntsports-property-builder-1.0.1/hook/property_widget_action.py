# :coding: utf-8
# :copyright: Copyright (c) 2024 ftrack

import logging
import ftrack_api
from ftrack_action_handler.action import BaseAction


class PropertiesWidgetAction(BaseAction):

    identifier = 'tntsports.properties.builder.action'
    label = 'Property Creator'
    description = 'Property Creator and Builder'
    icon = 'https://cobramachete.github.io/ftrack_icons/img/property_builder_icon.png'

    def discover(self, session, entities, event):

        user_id = event['source'].get('user', {}).get('username', None)
        currusername = session.api_user
        self.logger.info(user_id)
        self.logger.info(currusername)

        if user_id == currusername:
            # RETURN ACTION CONFIG IF ON A PROJECT OBJECT
            data = event['data']
            self.logger.info('Got selection: {0}'.format(data))

            # EVALUATING SELECTION
            selection = data.get('selection', [])
            
            if len(selection) == 1:
                self.logger.info(selection)
                # try:
                #     objitem = session.get('Project', selection[0]['entityId'])
                #     prid = objitem['project_id']
                #     baseid = objitem['id']
                    
                #     if objitem != None:
                #         if prid == baseid:
                #             return {
                #                 "items": [
                #                     {
                #                         "applicationIdentifier": APP_IDENTIFIER,
                #                         "label": "Tradecraft",
                #                         "variant": "v1.0",
                #                         "icon": appicon
                #                     }
                #                 ]
                #             }
                # except Exception:
                #     return []

                entity_id = selection[0]['entityId']
                self.logger.info(entity_id)
                try:
                    entity = session.get('Project', entity_id)
                    self.logger.info(f"Found TypedContext Entity: {entity}")
                    if entity and entity['project_id'] in (entity_id):
                        return True
                except Exception as e:
                    self.logger.warning(f"Error fetching entity: {e}")
                
        
    
    def launch(self, session, entities, event):
        """
        Method that responds to messages to launch the action.

        This will simply just return a web widget with the specified URL.
        """
        return {
            'success': True,
            'message': 'success',
            'type': 'widget',
            'url': 'https://cobramachete.github.io/Stargate/',
            'title': 'Property Creator',
            'width': 1200,
            'height': 600

        }


def register(session, **kw):
    '''Register plugin.'''
    if not isinstance(session, ftrack_api.Session):
        return

    action = PropertiesWidgetAction(session)
    action.register()


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    session = ftrack_api.Session(auto_connect_event_hub=True)
    register(session)

    session.event_hub.wait()



