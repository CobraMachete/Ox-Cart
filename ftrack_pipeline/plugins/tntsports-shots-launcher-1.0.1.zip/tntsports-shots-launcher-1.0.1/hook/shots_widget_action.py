# :coding: utf-8
# :copyright: Copyright (c) 2024 ftrack

import logging
import ftrack_api
from ftrack_action_handler.action import BaseAction


class ShotsWidgetAction(BaseAction):

    identifier = 'tntsports.launchshots.action'
    label = 'Shots! Shots! Shots!'
    description = 'Shots! Task Creator and Builder'
    icon = 'https://cobramachete.github.io/ftrack_icons/img/shots_icon.png'

    def __init__(self, session):
        super(ShotsWidgetAction, self).__init__(session)
        self.logger = logging.getLogger(__name__)

    def discover(self, session, entities, event):

        self.logger.info("Discovering Shots! Shots! Shots!")
        user_id = event['source'].get('user', {}).get('username', None)
        currusername = session.api_user
        self.logger.info(user_id)
        self.logger.info(currusername)

        if user_id == currusername:

            # RETURN ACTION CONFIG IF ON A PRODUCTION OBJECT
            data = event['data']
            self.logger.info('Got selection: {0}'.format(data))

            # EVALUATING SELECTION
            selection = data.get('selection', [])

            if len(selection) == 1:

                entity_id = selection[0]['entityId']
                try:
                    entity = session.get('TypedContext', entity_id)
                    self.logger.info(f"Found TypedContext Entity: {entity}")
                    if entity and entity['object_type']['name'] in ('Shot', 'Production'):
                        return True
                except Exception as e:
                    self.logger.warning(f"Error fetching entity: {e}")


    def launch(self, session, entities, event):
        
        if event['data'].get('actionIdentifier') != self.identifier:
            self.logger.info('Ignored launch event not meant for this action.')
            return

        selection = event['data'].get('selection', [])
        
        if len(selection) == 1:

            entity_id = selection[0]['entityId']

            try:
                entity = session.get('TypedContext', entity_id)
                self.logger.info(f"Shots! Shots! Shots! using TypedContext entity: {entity}")
                if entity and entity['object_type']['name'] in ('Shot', 'Production'):

                    self.logger.info(f"Using Entity: {entity} named {entity['object_type']['name']} for Shots! Shots! Shots!")

                    response = {
                        'success': True,
                        'message': 'success',
                        'type': 'widget',
                        'url': 'https://cobramachete.github.io/Ox-Cart/',
                        'title': 'Shots! Shots! Shots!',
                        'width': 1280,
                        'height': 650
                    }
                
                    self.logger.info(f"Returning response: {response}")
                    return response


            except Exception as e:
                self.logger.warning(f"Error fetching entity: {e}")
                    



def register(session, **kw):
    '''Register plugin.'''
    if not isinstance(session, ftrack_api.Session):
        return

    action = ShotsWidgetAction(session)
    action.register()
    logging.info("ShotsWidgetAction registered successfully!")


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    session = ftrack_api.Session(auto_connect_event_hub=True)
    register(session)
    session.event_hub.wait()
