# :coding: utf-8
# :copyright: Copyright (c) 2018 ftrack

import os
import functools
import logging

import ftrack_api
import ftrack_api.accessor.disk
import ftrack_api.entity.location
import platform
import structure

logger = logging.getLogger(
    'com.ftrack.wbd.customise_structure.location.custom_location_plugin'
)

# Name of the location plugin.
LOCATION_NAME = 'studio.central-storage-location'

if platform.system() == 'Windows':
    # Disk mount point.
    DISK_PREFIX = 'T:\\wfh'
else:
    DISK_PREFIX = '/Volumes/tscreative/wfh'



def configure_location(session, event):
    '''Listen.'''
    studiolocation = session.ensure('Location', {'name': LOCATION_NAME})
    studiolocation.accessor = ftrack_api.accessor.disk.DiskAccessor(prefix=DISK_PREFIX)
    studiolocation.structure = structure.StudioStructure()
    studiolocation.priority = 0
    

    logger.info('Registered location "{0}" at "{1}".'.format(LOCATION_NAME, DISK_PREFIX))


def register(api_object, **kw):
    '''Register location with *session*.'''

    if not isinstance(api_object, ftrack_api.Session):
        return

    if not DISK_PREFIX:
        logger.error('No disk prefix configured for location.')
        return

    if not os.path.exists(DISK_PREFIX) or not os.path.isdir(DISK_PREFIX):
        logger.error('Disk prefix location does not exist.')
        return

    api_object.event_hub.subscribe(
        'topic=ftrack.api.session.configure-location',
        functools.partial(configure_location, api_object),
    )
