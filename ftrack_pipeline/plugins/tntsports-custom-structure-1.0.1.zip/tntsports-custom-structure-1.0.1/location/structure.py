# :coding: utf-8
# :copyright: Copyright (c) 2018 ftrack

import shutil
import os
import re
import unicodedata
import logging
import platform
from pprint import pprint

import ftrack_api.symbol
import ftrack_api.structure.base
import ftrack_api.accessor.disk





class StudioStructure(ftrack_api.structure.base.Structure):
    '''Project hierarchy based structure that only supports Components.

    The resource identifier is generated from the project code, the name
    of objects in the project structure, asset name and version number::

        my_project/folder_a/folder_b/asset_name/v003

    If the component is a `FileComponent` then the name of the component and the
    file type are used as filename in the resource_identifier::

        my_project/folder_a/folder_b/asset_name/v003/foo.jpg

    If the component is a `SequenceComponent` then a sequence expression,
    `%04d`, is used. E.g. a component with the name `foo` yields::

        my_project/folder_a/folder_b/asset_name/v003/foo.%04d.jpg

    For the member components their index in the sequence is used::

        my_project/folder_a/folder_b/asset_name/v003/foo.0042.jpg

    The name of the component is added to the resource identifier if the
    component is a `ContainerComponent`. E.g. a container component with the
    name `bar` yields::

        my_project/folder_a/folder_b/asset_name/v003/bar

    For a member of that container the file name is based on the component name
    and file type::

        my_project/folder_a/folder_b/asset_name/v003/bar/baz.pdf

    '''

    def __init__(self, project_versions_prefix=None, illegal_character_substitute='_'):
        '''Initialise structure.

        If *project_versions_prefix* is defined, insert after the project code
        for versions published directly under the project::

            my_project/<project_versions_prefix>/v001/foo.jpg

        Replace illegal characters with *illegal_character_substitute* if
        defined.

        .. note::

            Nested component containers/sequences are not supported.

        '''
        super(StudioStructure, self).__init__()
        self.logger = logging.getLogger(
            'com.ftrack.wbd.customise_structure.location.StudioStructure'
        )
        self.project_versions_prefix = project_versions_prefix
        self.illegal_character_substitute = illegal_character_substitute

    def _get_parts(self, entity):
        """Return resource identifier parts from *entity* (defensive version)."""
        self.logger.debug('Get parts from entity : {}'.format(entity))
        session = entity.session

        # Resolve version safely before touching nested fields.
        version = entity.get('version')
        if version is ftrack_api.symbol.NOT_SET and entity.get('version_id'):
            version = session.get('AssetVersion', entity['version_id'])

        error_message = (
            'Component {0!r} must be attached to a committed '
            'version and a committed asset with a parent context.'.format(entity)
        )

        # Bail out if version is not committed.
        if version is ftrack_api.symbol.NOT_SET or version in session.created:
            raise ftrack_api.exception.StructureError(error_message)

        # Link must exist (Project → ... → Asset/Task path).
        link = version.get('link') or []
        if not link:
            raise ftrack_api.exception.StructureError(error_message)

        # --- SAFE READ: task/status/state/short (optional)
        short_state = None
        try:
            task = version.get('task')
            if task:
                status = task.get('status')
                state = status and status.get('state')
                short_state = state and state.get('short')
                if short_state:
                    self.logger.debug('Task short state: %s', short_state)
        except Exception:
            # Non-fatal: just log and continue.
            self.logger.debug('Task status/state not available during path build.')

        # Detect special containers ("Teams" / "Multicomp") from link.
        is_teams_obj = False
        is_multicomp_obj = False
        teamsitem = None
        multiitem = None

        for item in link:
            currid = item.get('id')
            if not currid:
                continue
            objtype = session.get('TypedContext', currid)
            if not objtype or 'object_type' not in objtype:
                continue
            ot_name = objtype['object_type'].get('name')
            if ot_name == 'Teams':
                teamsitem = objtype.get('name')
                is_teams_obj = True
                break
            if ot_name == 'Multicomp':
                multiitem = objtype.get('name')
                is_multicomp_obj = True
                break

        # Build structure names from link (excluding project and leaf).
        structure_names = [item.get('name') for item in link[1:-1] if item.get('name')]
        self.logger.debug(structure_names)

        # Project
        project_id = link[0]['id']
        project = session.get('Project', project_id)

        # Asset & type
        asset = version.get('asset')
        assettype = asset and asset['type'].get('name')
        self.logger.debug('THE ASSET TYPE IS:')
        self.logger.debug(asset and asset.get('name'))
        self.logger.debug(assettype)

        version_number = self._format_version(version.get('version') or 1)

        # Component file info
        asset_file_type = entity.get('file_type') or ''
        task = version.get('task')
        asset_task_name = task.get('name') if task else 'UNKNOWN_TASK'
        asset_task_type = (task.get('type') or {}).get('name') if task else None
        self.logger.debug(asset_task_type)

        # Teams/Multicomp labels
        teams_item_name = teamsitem if is_teams_obj else None
        multicomp_item_name = multiitem if is_multicomp_obj else None

        # Try to find a Shot in the link; fall back gracefully.
        shot_parent = None
        for item in link:
            ent = session.get('Shot', item.get('id'))
            if ent:
                shot_parent = ent.get('name')
                break

        if not shot_parent:
            # Fallback: use asset name or project name as base.
            candidate = (asset and asset.get('name')) or project.get('name')
            shot_parent = candidate or 'UNKNOWN'

        shot_split = (shot_parent.split('_')[0]) if isinstance(shot_parent, str) else 'UNKNOWN'
        self.logger.info(shot_split)

        # ----- Build component_shortname/component_fullname
        if is_teams_obj:
            if asset_file_type == '.aep':
                component_shortname = f'{shot_split}_{teams_item_name}'
                component_fullname  = f'{component_shortname}_{version_number}{asset_file_type}'
            elif asset_file_type == '.mov':
                component_shortname = f'{shot_split}_{teams_item_name}_{asset_task_name}'
                component_fullname  = f'{component_shortname}{asset_file_type}'
            else:
                component_shortname = f'{shot_split}_{teams_item_name}_{asset_task_name}'
                component_fullname  = f'{component_shortname}{asset_file_type}'

        elif is_multicomp_obj:
            if asset_file_type == '.aep':
                component_shortname = f'{shot_split}_{multicomp_item_name}'
                component_fullname  = f'{component_shortname}_{version_number}{asset_file_type}'
            elif asset_file_type == '.mov':
                component_shortname = f'{shot_split}_{asset_task_name}'
                component_fullname  = f'{component_shortname}{asset_file_type}'
            else:
                component_shortname = f'{shot_split}_{asset_task_name}'
                component_fullname  = f'{component_shortname}{asset_file_type}'

        else:
            component_shortname = f'{shot_split}_{asset_task_name}'
            component_fullname  = f'{component_shortname}{asset_file_type}'

        self.logger.debug(component_fullname)
        self.logger.debug(component_shortname)

        # ----- Optionally rename the component & (risky) asset naming
        if asset_file_type == '.aep':
            if asset_task_type != 'Template_Build':
                entity['name'] = f'{component_shortname}_{version_number}'
                entity['version']['asset']['name'] = f'{component_shortname}_{assettype}'
                self.logger.debug(entity['name'])
                self.logger.debug(entity['version']['asset']['name'])
            else:
                # Template-specific variants
                if is_teams_obj:
                    suffix = "_GLOBAL_TEMPLATE" if asset_task_name == "GLOBAL_TEMPLATE" else "_TEMPLATE"
                    entity['name'] = f'{shot_split}_{teams_item_name}{suffix}_{version_number}'
                    entity['version']['asset']['name'] = f'{shot_split}_{teams_item_name}{suffix}_{assettype}'
                elif is_multicomp_obj:
                    suffix = "_GLOBAL_TEMPLATE" if asset_task_name == "GLOBAL_TEMPLATE" else "_TEMPLATE"
                    entity['name'] = f'{shot_split}_{multicomp_item_name}{suffix}_{version_number}'
                    entity['version']['asset']['name'] = f'{shot_split}_{multicomp_item_name}{suffix}_{assettype}'
                else:
                    suffix = "_GLOBAL_TEMPLATE" if asset_task_name == "GLOBAL_TEMPLATE" else "_TEMPLATE"
                    entity['name'] = f'{shot_split}{suffix}_{version_number}'
                    entity['version']['asset']['name'] = f'{shot_split}{suffix}_{assettype}'


                self.logger.debug(entity['name'])
                self.logger.debug(entity['version']['asset']['name'])
        else:
            entity['name'] = f'{component_shortname}_{version_number}'
            entity['version']['asset']['name'] = f'{component_shortname}_{assettype}'

            
            
            self.logger.info(entity['name'])
            self.logger.info(entity['version']['asset']['name'])

        # ----- Path routing: guard against short structure_names
        def has_last(seq, name):
            return len(seq) >= 1 and seq[-1] == name

        def has_second_last(seq, name):
            return len(seq) >= 2 and seq[-2] == name

        # Teams routing
        if is_teams_obj:
            
            if has_second_last(structure_names, '02_cmp'):
                if asset_file_type == '.aep':
                    if asset_task_type in ('Comp', 'Container'):
                        if structure_names:
                            structure_names.pop()  # remove leaf
                        structure_names.append('_archive')
                    elif asset_task_type == 'Template_Build':
                        if structure_names:
                            structure_names.pop()
                        structure_names.append('_TEMPLATE')
                        structure_names.append('_archive')
                elif asset_file_type == '.mov':
                    if len(structure_names) >= 2:
                        structure_names.pop()
                        structure_names.pop()
                    structure_names.extend(['03_review', '_archive', teams_item_name])
                else:
                    if len(structure_names) >= 2:
                        structure_names.pop()
                        structure_names.pop()
                    structure_names.extend(['03_review', '_archive', teams_item_name])

            if has_second_last(structure_names, '00_3D'):
                if structure_names:
                    structure_names.pop()

        # Multicomp routing
        elif is_multicomp_obj:
            
            if has_second_last(structure_names, '02_cmp'):
                if asset_file_type == '.aep':
                    if asset_task_type in ('Comp', 'Container'):
                        if structure_names:
                            structure_names.pop()
                        structure_names.append('_archive')
                    elif asset_task_type == 'Template_Build':
                        if structure_names:
                            structure_names.pop()
                        structure_names.append('_TEMPLATE')
                        structure_names.append('_archive')
                elif asset_file_type == '.mov':
                    if len(structure_names) >= 2:
                        structure_names.pop()
                        structure_names.pop()
                    structure_names.extend(['03_review', '_archive', multicomp_item_name])
                else:
                    if len(structure_names) >= 2:
                        structure_names.pop()
                        structure_names.pop()
                    structure_names.extend(['03_review', '_archive', multicomp_item_name])

            if has_second_last(structure_names, '00_3D'):
                if structure_names:
                    structure_names.pop()

        # Default routing
        else:
            if has_last(structure_names, '02_cmp'):
                
                if asset_file_type == '.aep':
                    if asset_task_type == 'Comp':
                        structure_names.append('_archive')
                    elif asset_task_type == 'Template_Build':
                        
                        structure_names.extend(['_TEMPLATE', '_archive'])
                elif asset_file_type == '.mov':
                    # replace trailing 02_cmp with 03_review/_archive
                    structure_names = [n for n in structure_names if n != '02_cmp']
                    structure_names.extend(['03_review', '_archive'])
                else:
                    structure_names = [n for n in structure_names if n != '02_cmp']
                    structure_names.append('03_review')

            elif has_last(structure_names, '00_3D'):
                if asset_task_type == 'C4D':
                    structure_names.append('C4D')
                elif asset_task_type == 'MAYA':
                    structure_names.append('MAYA')
                elif asset_task_type == '3dsMAX':
                    structure_names.append('3dsMAX')
                elif asset_task_type == 'Template_Build':
                    structure_names.append('Template_Build')



        if has_last(structure_names, '02_cmp'):
                
                if asset_file_type == '.aep':
                    if asset_task_type == 'Comp':
                        structure_names.append('_archive')
                    elif asset_task_type == 'Template_Build':
                        
                        structure_names.extend(['_TEMPLATE', '_archive'])
                elif asset_file_type == '.mov':
                    # replace trailing 02_cmp with 03_review/_archive
                    structure_names = [n for n in structure_names if n != '02_cmp']
                    structure_names.extend(['03_review', '_archive'])
                else:
                    structure_names = [n for n in structure_names if n != '02_cmp']
                    structure_names.append('03_review')

        # ----- Build parts
        parts = [project.get('name')]
        if structure_names:
            parts.extend(structure_names)
        elif self.project_versions_prefix:
            parts.append(self.project_versions_prefix)

        self.logger.debug('Get parts result : {}'.format(parts))
        return [self.sanitise_for_filesystem(part) for part in parts]



    def _format_version(self, number):
        '''Return a formatted string representing version *number*.'''
        self.logger.debug('formatting version : {}'.format(number))

        return 'v{0:03d}'.format(number)

    def sanitise_for_filesystem(self, value):
        '''Return *value* with illegal filesystem characters replaced.

        An illegal character is one that is not typically valid for filesystem
        usage, such as non ascii characters, or can be awkward to use in a
        filesystem, such as spaces. Replace these characters with
        the character specified by *illegal_character_substitute* on
        initialisation. If no character was specified as substitute then return
        *value* unmodified.

        '''
        self.logger.debug('Sanitising for file system : {}'.format(value))

        if self.illegal_character_substitute is None:
            return value

        if isinstance(value, str):
            try:
                value = value.decode('utf-8')
            except AttributeError: 
                value = value
                

        value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore')
        value = re.sub('[^\w\.-]', self.illegal_character_substitute, value.decode())
        return str(value.strip())

    def get_resource_identifier(self, entity, context=None):
        '''Return a resource identifier for supplied *entity*.

        *context* can be a mapping that supplies additional information, but
        is unused in this implementation.


        Raise a :py:exc:`ftrack_api.exeption.StructureError` if *entity* is not
        attached to a committed version and a committed asset with a parent
        context.

        '''

        self.logger.debug(
            'Gettting resource identifier'
            ' for entity : {} and context : {}'.format(entity, context)
        )

        if entity.entity_type in ('FileComponent',):
            container = entity['container']

            if container:
                # Get resource identifier for container.
                container_path = self.get_resource_identifier(container)

                if container.entity_type in ('SequenceComponent',):
                    # Strip the sequence component expression from the parent
                    # container and back the correct filename, i.e.
                    # /sequence/component/sequence_component_name.0012.exr.
                    name = '{0}.{1}{2}'.format(
                        container['name'], entity['name'], entity['file_type']
                    )
                    parts = [
                        os.path.dirname(container_path),
                        self.sanitise_for_filesystem(name),
                    ]

                else:
                    # Container is not a sequence component so add it as a
                    # normal component inside the container.
                    name = entity['name'] + entity['file_type']
                    parts = [container_path, self.sanitise_for_filesystem(name)]

            else:
                # File component does not have a container, construct name from
                # component name and file type.
                parts = self._get_parts(entity)
                name = entity['name'] + entity['file_type']
                parts.append(self.sanitise_for_filesystem(name))

        elif entity.entity_type in ('SequenceComponent',):
            # Create sequence expression for the sequence component and add it
            # to the parts.
            parts = self._get_parts(entity)
            sequence_expression = self._get_sequence_expression(entity)
            parts.append(
                '{0}.{1}{2}'.format(
                    self.sanitise_for_filesystem(entity['name']),
                    sequence_expression,
                    self.sanitise_for_filesystem(entity['file_type']),
                )
            )

        elif entity.entity_type in ('ContainerComponent',):
            # Add the name of the container to the resource identifier parts.
            parts = self._get_parts(entity)
            parts.append(self.sanitise_for_filesystem(entity['name']))

        else:
            raise NotImplementedError(
                'Cannot generate resource identifier for unsupported '
                'entity {0!r}'.format(entity)
            )

        return self.path_separator.join(parts)
        

    def _get_component_fullpath(self, component, session):

        # LOCATION AND STRUCTURE CONFIG
        STUDIO_LOCATION_NAME = 'studio.central-storage-location'
        mystudiolocation = session.query(f'Location where name is "{STUDIO_LOCATION_NAME}"').first()

        crid = self.get_resource_identifier(component)
        if platform.system() == "Windows":
            crid = crid.replace('/', '\\')

        component_full_path = os.path.join(mystudiolocation.accessor.prefix, crid)
        
        # CONSIDER DOING SOME ERROR CHECKING AND COMPONENT AVAILABILITY BEFORE RETURNING
        return component_full_path
    


                        


        


