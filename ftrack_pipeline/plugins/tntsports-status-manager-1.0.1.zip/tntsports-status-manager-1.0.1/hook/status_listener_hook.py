# :coding: utf-8
from __future__ import annotations

import functools
import logging
import os
import platform
from contextlib import contextmanager
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
from ftrack_api.symbol import Symbol, NOT_SET

import ftrack_api

logger = logging.getLogger("com.tntsport.manage_status_change")
logger.setLevel(logging.INFO)

# --------------------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------------------

# Allow overrides via env (useful for dev/machine diffs)
ENV_SAN_ROOT = os.getenv("TNT_SAN_ROOT")  # e.g. "/Volumes/tscreative/wfh" or "T:\\wfh"
DEFAULT_SAN_ROOT_MAC = "/Volumes/tscreative/wfh"
DEFAULT_SAN_ROOT_WIN = r"T:\wfh"

TEMP_META_FLAG = "TEMP_STAT_UPDATE"  # used to stop self-trigger loops


# --------------------------------------------------------------------------------------
# Utilities
# --------------------------------------------------------------------------------------

def san_root() -> str:
    """Return base SAN root, honoring env override."""
    if ENV_SAN_ROOT:
        return ENV_SAN_ROOT
    if platform.system() == "Windows":
        return DEFAULT_SAN_ROOT_WIN
    return DEFAULT_SAN_ROOT_MAC


@contextmanager
def commit_or_rollback(session: ftrack_api.Session):
    """Commit on success, rollback on exception. Also resets session on success."""
    try:
        yield
        session.commit()
        session.reset()
    except Exception:
        session.rollback()
        raise


def ensure_dirs(root: str, *parts: str) -> str:
    """Create directory and return its absolute path."""
    path = os.path.join(root, *parts)
    os.makedirs(path, exist_ok=True)
    return path


def ensure_tree(base: str, tree: Dict[str, Iterable[str]]):
    """
    Create a folder tree.

    tree format:
      {
        "folderA": [],
        "folderB": ["sub1", "sub2"],
        ...
      }
    """
    for top, subs in tree.items():
        top_path = ensure_dirs(base, top)
        for sub in subs:
            ensure_dirs(top_path, sub)


def is_status_change(entity: dict) -> bool:
    """Return True if updated *entity* is a task status change."""
    is_task_entity = entity.get("entityType") == "task" or entity.get("entity_type") == "Task"
    is_add_update = entity.get("action") in {"add", "update"}
    changed_keys = set(entity.get("keys", []))
    status_changed = "statusid" in changed_keys
    # Keep a single concise log line (the earlier code logged each piece individually)
    logger.info(f"[is_status_change] task={is_task_entity} add/update={is_add_update} status_changed={status_changed}")
    return is_task_entity and is_add_update and status_changed


def send_message_to_user(session: ftrack_api.Session, user_id: str, message: str):
    """Pop up a message for the active *user_id*."""
    try:
        session.event_hub.publish(
            ftrack_api.event.base.Event(
                topic="ftrack.action.trigger-user-interface",
                data=dict(
                    type="message",
                    success=True,
                    message=message,
                ),
                target=f'applicationId=ftrack.client.web and user.id="{user_id}"',
            ),
            on_error="ignore",
        )
    except Exception:
        logger.exception("Failed to send UI message")


# --------------------------------------------------------------------------------------
# Folder builders
# --------------------------------------------------------------------------------------

def build_shot_folders(link_names: Sequence[str]) -> None:
    """
    Build standard shot structure under SAN root, e.g. ['PROJECT', 'SEQ', 'SHOT'].

    Structure mirrors the original but built from concise trees.
    """
    base = ensure_dirs(san_root(), *link_names)

    # Top-level
    ensure_tree(
        base,
        {
            "_archive": [],
            "00_3D": ["3dsmax", "C4D", "Houdini", "Maya", "renders"],
            "01_design": ["working", "4_cmp", "example", "PSD", "reference"],
            "02_cmp": ["_archive", "_TEMPLATE"],
            "03_review": ["_archive"],
            "04_delivery": [],
        },
    )

    # 3ds Max branches
    ensure_tree(
        os.path.join(base, "00_3D", "3dsmax"),
        {
            "vpost": [],
            "archives": [],
            "autoback": [],
            "downloads": [],
            "export": [],
            "express": [],
            "import": [],
            "materiallibraries": [],
            "previews": [],
            "proxies": [],
            "renderoutput": [],
            "renderpresets": [],
            "sceneassets": [],
            "scenes": [],
            "simcache": [],
        },
    )

    # C4D, Houdini, Maya
    ensure_tree(os.path.join(base, "00_3D", "C4D"), {"tex": [], "work": []})
    ensure_tree(os.path.join(base, "00_3D", "Houdini"), {"tex": [], "alembic": [], "fbx": [], "geo": [], "hip": [], "img": [], "sim": []})
    ensure_tree(os.path.join(base, "00_3D", "Maya"), {"tex": [], "geo": [], "img": [], "particles": [], "ref": [], "scn": [], "scripts": []})

    # _TEMPLATE/_archive
    ensure_dirs(base, "02_cmp", "_TEMPLATE", "_archive")


def build_show_package_folders(link_names: Sequence[str]) -> None:
    """
    Build show package structure (original 'Show_package' branch).
    """
    base = ensure_dirs(san_root(), *link_names)

    ensure_tree(
        base,
        {
            "_archive": [],
            "00_print": [],
            "01_assets": ["_collects", "audio", "docs", "editorial", "fonts", "player_photos_cutouts", "schedule", "scripts", "stock", "styleguides"],
            "02_dev": [],
            "03_brdcast_gfx": [],
            "04_UE": [],
            "05_3D": ["DEV", "LIB"],
        },
    )

    ensure_tree(os.path.join(base, "05_3D", "DEV"),
                {"3dsmax": [], "AE": [], "C4D": [], "Houdini": [], "Maya": [], "Nuke": [], "RENDERS": [], "Substance": [], "Zbrush": []})
    ensure_tree(os.path.join(base, "05_3D", "LIB"),
                {"ENVIRONMENTS": [], "FLAGS": [], "LOGOS": [], "PROPS": [], "TEXTURES": []})


# --------------------------------------------------------------------------------------
# Status sync helpers
# --------------------------------------------------------------------------------------

def _project_schema(session: ftrack_api.Session, name: str):
    return session.query(f'ProjectSchema where name is "{name}"').one()


def _statuses_by_name_for_task(session: ftrack_api.Session, project_schema_name: str) -> Dict[str, dict]:
    schema = _project_schema(session, project_schema_name)
    return {s["name"]: s for s in schema.get_statuses(schema="Task")}


def _statuses_by_name_for_task_type(session: ftrack_api.Session, project_schema_name: str, type_name: str) -> Dict[str, dict]:
    schema = _project_schema(session, project_schema_name)
    # Any task with given type is enough to fetch its id
    task = session.query(f'Task where type.name is "{type_name}"').first()
    if not task:
        return {}
    return {s["name"]: s for s in schema.get_statuses(schema="Task", type_id=task["type"]["id"])}


def update_asset_statuses_to_task(session: ftrack_api.Session, task: dict) -> None:
    """Set latest AssetVersions on the task to match the task's status."""
    task_status = task["status"]
    # If we set TEMP_META_FLAG earlier, clear it now (prevents loops)
    try:
        if task.get("metadata", {}).get(TEMP_META_FLAG) in (True, "True", "true", "1"):
            del task["metadata"][TEMP_META_FLAG]
            logger.info(f'Removed {TEMP_META_FLAG} metadata from task "{task["name"]}".')
    except Exception:
        logger.exception("Error cleaning TEMP_META_FLAG metadata (non-fatal).")

    assets = session.query(
        f'AssetVersion where task_id is "{task["id"]}" and is_latest_version is true'
    ).all()

    if not assets:
        logger.info(f'No assets found for task "{task["name"]}"')
        return

    with commit_or_rollback(session):
        for av in assets:
            if av["status"]["id"] != task_status["id"]:
                logger.info(f'Updating asset "{av["asset"]["name"]}" status → {task_status["name"]}')
                av["status"] = task_status


def update_task_and_assets_to_asset(session: ftrack_api.Session, asset_version_id: str) -> None:
    """Set the task (and its latest AssetVersions) to the given AssetVersion's status."""
    av = session.get("AssetVersion", asset_version_id)
    if not av:
        logger.warning(f"AssetVersion {asset_version_id} not found.")
        return

    task = session.get("Task", av["task_id"])
    if not task:
        logger.info(f'No task found for asset "{av["asset"]["name"]}".')
        return

    asset_status = av["status"]

    # Reentrancy guard: mark task so when we propagate back to assets we can skip loops
    task.setdefault("metadata", {})[TEMP_META_FLAG] = True

    related_assets = session.query(
        f'AssetVersion where task_id is "{task["id"]}" and is_latest_version is true'
    ).all()

    with commit_or_rollback(session):
        # Align latest assets
        for other in related_assets:
            if other["id"] != av["id"] and other["status"]["id"] != asset_status["id"]:
                logger.info(f'Align asset "{other["asset"]["name"]}" → {asset_status["name"]}')
                other["status"] = asset_status
        # Align task
        if task["status"]["id"] != asset_status["id"]:
            logger.info(f'Align task "{task["name"]}" → {asset_status["name"]}')
            task["status"] = asset_status


def compare_task_statuses(session: ftrack_api.Session, entity: dict, project_schema_name: str, publish_origin: str) -> Tuple[Optional[str], str]:
    """
    Return a tuple of (signal, payload) for specific transitions you care about.
    Current behaviors preserved from original:
      - If NOT from CONNECT and Not Started → In Progress → 'PROGSTARTED'
      - If from CONNECT and Not Started → In Progress → 'HALTCHANGE' (return old status id)
    """
    changes = entity.get("changes") or {}
    tskstat = changes.get("statusid") or {}
    old_stat = tskstat.get("old")
    new_stat = tskstat.get("new")
    if not old_stat or not new_stat:
        return None, "None"

    schema = _project_schema(session, project_schema_name)
    status_by_id = {s["id"]: s["name"] for s in schema.get_statuses(schema="Task")}

    old_name = status_by_id.get(old_stat, "").lower()
    new_name = status_by_id.get(new_stat, "").lower()

    if publish_origin != "CONNECT":
        if old_name == "not started" and new_name == "in progress":
            return "PROGSTARTED", "None"
    else:
        if old_name == "not started" and new_name == "in progress":
            return "HALTCHANGE", old_stat

    return None, "None"


def get_task_id_from_asset_version(session: ftrack_api.Session, av_id: str) -> Optional[str]:
    av = session.get("AssetVersion", av_id)
    return av["task_id"] if av else None


def change_matching_3d_stat(session: ftrack_api.Session, tsk: dict, new_stat: dict) -> None:
    """Sync status between Comp and 3D tasks (C4D/MAYA) based on your rules."""
    try:
        task_type = tsk["type"]["name"]
        parent_ctx = tsk["parent"]
        parent_name = parent_ctx["name"]
        parent_id = parent_ctx["id"]

        parent_type_obj = session.get("TypedContext", parent_id)
        parent_type = parent_type_obj["object_type"]["name"]

        proj_schema_name = tsk["project"]["project_schema"]["name"]

        task_statuses = _statuses_by_name_for_task(session, proj_schema_name)
        comp_statuses = _statuses_by_name_for_task_type(session, proj_schema_name, "Comp")

        def shot_from_context() -> Optional[dict]:
            # Comp or 3D under Folder → parent.parent is shot
            # Teams/Multicomp nesting → parent.parent.parent is shot
            if parent_type == "Folder":
                shot_id = tsk["parent"]["parent"]["id"]
            else:
                shot_id = tsk["parent"]["parent"]["parent"]["id"]
            return session.get("Shot", shot_id)

        def find_matching_from_comp() -> Optional[dict]:
            shot = shot_from_context()
            if not shot:
                return None
            if parent_type == "Folder":
                q = (
                    'Task where parent.name is "00_3D" '
                    f'and parent.parent.name is "{shot["name"]}" '
                    f'and name is "{tsk["name"]}"'
                )
            else:
                q = (
                    f'Task where parent.name is "{parent_name}" '
                    f'and parent.parent.parent.name is "{shot["name"]}" '
                    f'and name is "{tsk["name"]}" and type.name is_not "Comp"'
                )
            return session.query(q).first()

        def find_matching_from_3d() -> Optional[dict]:
            shot = shot_from_context()
            if not shot:
                return None
            if parent_type == "Folder":
                q = (
                    'Task where parent.name is "02_cmp" '
                    f'and parent.parent.name is "{shot["name"]}" '
                    f'and name is "{tsk["name"]}" and type.name is "Comp"'
                )
            else:
                q = (
                    f'Task where parent.name is "{parent_name}" '
                    f'and parent.parent.parent.name is "{shot["name"]}" '
                    f'and name is "{tsk["name"]}" and type.name is "Comp"'
                )
            return session.query(q).first()

        def set_status_if_needed(task: dict, desired_name: str, status_map: Dict[str, dict]) -> bool:
            if not task:
                return False
            current = task["status"]["name"]
            if current == desired_name:
                logger.info(f"Status already '{desired_name}' for {task['name']}; no change.")
                return False
            status_obj = status_map.get(desired_name)
            if not status_obj:
                logger.warning(f"Desired status '{desired_name}' not in schema.")
                return False
            logger.info(f"Changing {task['name']} status: {current} → {desired_name}")
            with commit_or_rollback(session):
                task["status"] = session.get("Status", status_obj["id"])
            return True

        # Comp → 3D
        if task_type == "Comp":
            tgt = find_matching_from_comp()
            if new_stat["name"] == "Revise_3D":
                set_status_if_needed(tgt, "Revise", task_statuses)
            return

        # 3D → Comp
        if task_type in ("C4D", "MAYA"):
            tgt = find_matching_from_3d()
            if new_stat["name"] == "Revise":
                set_status_if_needed(tgt, "Revise_3D", comp_statuses)
            elif new_stat["name"] == "Ready For Comp":
                set_status_if_needed(tgt, "Ready For Comp", comp_statuses)
            return

        logger.info(f"Ignoring task type '{task_type}' for status sync.")
    except Exception as e:
        logger.exception(f"change_matching_3d_stat failed: {e}")

def _ids_in_clause(ids: set[str]) -> str:
    """
    Return a string like: ("id1","id2","id3")
    Assumes IDs are safe (UUIDs). If empty, returns ("").
    """
    if not ids:
        return '("")'
    quoted = '","'.join(sorted(ids))
    return f'("{quoted}")'



def _is_symbol(x) -> bool:
    return isinstance(x, Symbol)

def get_project(session, task):
    """Return a fully-hydrated Project entity for this task, or None."""
    proj = task.get("project")
    if _is_symbol(proj) or not proj:
        proj_id = task.get("project_id")
        if proj_id:
            return session.get("Project", proj_id)
        return None
    # ensure fully loaded (sometimes relation is a shallow proxy)
    try:
        _ = proj["id"]  # touch to coerce load
        return proj
    except Exception:
        return session.get("Project", proj.get("id")) if proj and proj.get("id") else None

def get_project_schema_name(session, task) -> Optional[str]:
    """Robustly fetch the project's schema name for a task."""
    proj = get_project(session, task)
    if not proj:
        return None
    schema = proj.get("project_schema")
    if _is_symbol(schema) or not schema:
        # re-fetch project fully, then re-read
        proj = session.get("Project", proj["id"])
        schema = proj.get("project_schema")
    if _is_symbol(schema) or not schema:
        return None
    name = schema.get("name")
    return None if _is_symbol(name) else name

def get_custom_attributes(task) -> dict:
    """Return task custom_attributes as a dict (never Symbol/None)."""
    catts = task.get("custom_attributes")
    return {} if _is_symbol(catts) or not catts else catts


# --------------------------------------------------------------------------------------
# Sibling-status syncing via CustomAttributeLink (Link CA)
# --------------------------------------------------------------------------------------

SIBLING_LINK_KEY = "sibling_tasks"     # exact config key
SIBLING_LINK_LABEL = "Sibling Tasks"   # label (fallback match)

# cache: (project_id or "GLOBAL") -> set(conf_ids)
_SIBLING_CONF_CACHE: dict[str, set[str]] = {}

def _safe_iter(x):
    if not x:
        return []
    return x if isinstance(x, (list, tuple, set)) else [x]

def _ids_in_clause(ids: set[str]) -> str:
    if not ids:
        return '("")'
    quoted = '","'.join(sorted(ids))
    return f'("{quoted}")'

def _get_sibling_conf_ids(session, task) -> set[str]:
    """
    Find all CustomAttributeLinkConfiguration ids that correspond to our sibling link CA.
    Prefer those scoped to the task's project, but include any that match key/label.
    Avoid relying on configuration.name (not present) and don't assume entity_type casing.
    """
    proj_id = task["project"]["id"] if task.get("project") else None
    cache_key = proj_id or "GLOBAL"
    if cache_key in _SIBLING_CONF_CACHE:
        return _SIBLING_CONF_CACHE[cache_key]

    conf_ids: set[str] = set()

    # 1) Project-scoped by exact key
    if proj_id:
        res = session.query(
            'CustomAttributeLinkConfiguration where '
            f'key is "{SIBLING_LINK_KEY}" and project_id is "{proj_id}"'
        ).all() or []
        conf_ids.update(c["id"] for c in res if c.get("id"))

    # 2) Project-scoped by label (fallback)
    if proj_id and not conf_ids:
        res = session.query(
            'CustomAttributeLinkConfiguration where '
            f'label is "{SIBLING_LINK_LABEL}" and project_id is "{proj_id}"'
        ).all() or []
        conf_ids.update(c["id"] for c in res if c.get("id"))

    # 3) Any config anywhere by key
    if not conf_ids:
        res = session.query(
            'CustomAttributeLinkConfiguration where '
            f'key is "{SIBLING_LINK_KEY}"'
        ).all() or []
        conf_ids.update(c["id"] for c in res if c.get("id"))

    # 4) Any config anywhere by label (last fallback)
    if not conf_ids:
        res = session.query(
            'CustomAttributeLinkConfiguration where '
            f'label is "{SIBLING_LINK_LABEL}"'
        ).all() or []
        conf_ids.update(c["id"] for c in res if c.get("id"))

    _SIBLING_CONF_CACHE[cache_key] = conf_ids
    return conf_ids

def _gather_relation_links(task):
    """Collect any link rows exposed on the Task entity in any of the common relations."""
    rels = []
    for attr in ("custom_attribute_links", "custom_attribute_links_from", "custom_attribute_links_to"):
        rel = task.get(attr)
        if rel:
            rels.extend(_safe_iter(rel))
    return rels

def _collect_ids_from_links_for_task(task, links, valid_conf_ids: set[str]) -> set[str]:
    """
    Inspect link rows (any direction), return sibling task ids for *task*,
    only when configuration_id matches one of valid_conf_ids.
    """
    me = task["id"]
    out: set[str] = set()
    for link in _safe_iter(links):
        try:
            conf_id = link.get("configuration_id")
            if not conf_id:
                cfg = link.get("configuration")
                conf_id = cfg.get("id") if cfg else None
            if conf_id not in valid_conf_ids:
                continue

            f_id, t_id = link.get("from_id"), link.get("to_id")
            # Do NOT filter by entity_type, it differs across sites; rely on ids only.
            if f_id == me and t_id and t_id != me:
                out.add(t_id)
            if t_id == me and f_id and f_id != me:
                out.add(f_id)
        except Exception:
            logger.exception("Error parsing CustomAttributeLink row (ignored).")
    return out

def _fetch_sibling_task_ids(session, task) -> set[str]:
    """
    Get sibling Task IDs for *task* by:
      1) reading any link relations on the entity,
      2) falling back to direct table queries for both directions.
    """
    me = task["id"]
    conf_ids = _get_sibling_conf_ids(session, task)
    if not conf_ids:
        logger.warning(f"No CustomAttributeLinkConfiguration found for key/label '{SIBLING_LINK_KEY}'/'{SIBLING_LINK_LABEL}'.")
        return set()

    # 1) Fast path: relations
    rel_links = _gather_relation_links(task)
    ids = _collect_ids_from_links_for_task(task, rel_links, conf_ids)
    if ids:
        return ids

    # 2) Fallback: explicit table queries, no entity_type filters (avoid casing issues)
    in_clause = _ids_in_clause(conf_ids)

    # outgoing: me -> others
    q_from = session.query(
        'CustomAttributeLink where '
        f'configuration_id in {in_clause} and '
        f'from_id is "{me}"'
    ).all() or []

    # incoming: others -> me
    q_to = session.query(
        'CustomAttributeLink where '
        f'configuration_id in {in_clause} and '
        f'to_id is "{me}"'
    ).all() or []

    return _collect_ids_from_links_for_task(task, list(q_from) + list(q_to), conf_ids)

def sync_sibling_task_statuses(session, source_task) -> None:
    """
    Make all sibling tasks (Link CA 'sibling_tasks') match the status of *source_task*.
    No-ops when already matching to prevent event loops.
    """
    try:
        sibling_ids = _fetch_sibling_task_ids(session, source_task)
        if not sibling_ids:
            return

        src_status = source_task["status"]
        src_status_id = src_status["id"]
        src_status_name = src_status["name"]

        siblings = []
        for tid in sibling_ids:
            try:
                t = session.get("Task", tid)
                if t:
                    siblings.append(t)
            except Exception:
                logger.exception(f"Failed to fetch sibling Task {tid} (ignored).")

        if not siblings:
            return

        changed = False
        with commit_or_rollback(session):
            for sib in siblings:
                cur = sib.get("status")
                if not cur or cur["id"] != src_status_id:
                    logger.info(
                        f'[siblings] {sib.get("name")} ({sib["id"]}): '
                        f'{cur["name"] if cur else "None"} → {src_status_name}'
                    )
                    sib["status"] = src_status
                    changed = True

        if not changed:
            logger.info("[siblings] Already matched; no changes.")
    except Exception as e:
        logger.exception(f"sync_sibling_task_statuses failed: {e}")


# --------------------------------------------------------------------------------------
# Event handler
# --------------------------------------------------------------------------------------

def handle_show_package_add(session: ftrack_api.Session, entity: dict, user_id: str) -> None:
    show_pkg = session.get("Show_package", entity["entityId"])
    if not show_pkg:
        return
    link_names = [p["name"] for p in show_pkg["link"]]
    build_show_package_folders(link_names)
    send_message_to_user(session, user_id, "Show package created. Folder structure is ready!")


def handle_asset_version_update(session: ftrack_api.Session, entity: dict) -> None:
    av_id = entity["entityId"]
    update_task_and_assets_to_asset(session, av_id)


def handle_task_status_update(session: ftrack_api.Session, entity: dict, user_id: str) -> None:
    task = session.get("Task", entity["entityId"])
    if not task:
        return

    # If this is our own change (TEMP flag), still let assets align (the aligner will clear the flag)
    changes = entity.get("changes") or {}
    status_change = changes.get("statusid")
    if status_change and status_change.get("new"):
        new_status_obj = session.get("Status", status_change["new"])
        if new_status_obj:
            # Comp/3D sync bridge
            if new_status_obj["name"] in ("Revise", "Revise_3D", "Ready For Comp"):
                change_matching_3d_stat(session, task, new_status_obj)

    # Align assets with task
    update_asset_statuses_to_task(session, task)

    conf_ids = _get_sibling_conf_ids(session, task)
    logger.info(f"sibling_tasks conf_ids: {sorted(conf_ids)}")
    logger.info("relations present: "
                f"links={'y' if task.get('custom_attribute_links') else 'n'}, "
                f"from={'y' if task.get('custom_attribute_links_from') else 'n'}, "
                f"to={'y' if task.get('custom_attribute_links_to') else 'n'}")

    # Raw counts from fallback queries (no type filters)
    if conf_ids:
        in_clause = _ids_in_clause(conf_ids)
        cnt_from = session.query(
            'CustomAttributeLink where '
            f'configuration_id in {in_clause} and '
            f'from_id is "{task["id"]}"'
        ).all()
        cnt_to = session.query(
            'CustomAttributeLink where '
            f'configuration_id in {in_clause} and '
            f'to_id is "{task["id"]}"'
        ).all()
        logger.info(f"fallback link counts: from={len(cnt_from or [])}, to={len(cnt_to or [])}")




    # Sync siblings to this task's status (no-ops if already matching)
    sync_sibling_task_statuses(session, task)
    

    # Folder building on specific transitions
    prj_schema_name = get_project_schema_name(session, task) or ""
    publish_origin = get_custom_attributes(task).get("publish_origin", "")

    signal, payload = compare_task_statuses(session, entity, prj_schema_name, publish_origin)
    if signal == "PROGSTARTED":
        # Find shot parent from entity parents (as original)
        shot_id = ""
        for p in entity.get("parents", []):
            if p.get("entity_type") == "Shot":
                shot_id = p.get("entityId")
                break

        if shot_id:
            shot = session.get("Shot", shot_id)
            if shot:
                link_names = [p["name"] for p in shot["link"]]
                build_shot_folders(link_names)
                send_message_to_user(session, user_id, "Task moved to In Progress. Shot folders created.")

    elif signal == "HALTCHANGE":
        # Revert and clear marker if this came from CONNECT
        with commit_or_rollback(session):
            task["custom_attributes"]["publish_origin"] = ""
            task["status_id"] = payload  # old status id
        send_message_to_user(session, user_id, "Connect-origin status change halted & reverted.")


def status_changes_event_listener(session: ftrack_api.Session, event: dict) -> None:
    # Only act on current user's events (mirrors your original intent)
    user_id = event.get("source", {}).get("user", {}).get("id")
    curr_user = session.query(f'User where username is "{session.api_user}"').one()
    if user_id != curr_user["id"]:
        return

    entities = event.get("data", {}).get("entities", []) or []
    logger.info(f"[event] entities={len(entities)}")
    

    for entity in entities:
        action = entity.get("action")  # 'add' or 'update'
        ent_type = entity.get("entity_type") or entity.get("entityType")
        if not action or not ent_type:
            continue

        # Handle non-task entities first
        if ent_type == "Show_package" and action == "add":
            handle_show_package_add(session, entity, user_id)
            continue

        # AssetVersion status update
        if ent_type == "AssetVersion" and action == "update":
            handle_asset_version_update(session, entity)
            continue

        # Task status update
        if ent_type == "Task" and action == "update" and is_status_change(entity):
            handle_task_status_update(session, entity, user_id)
            continue


# --------------------------------------------------------------------------------------
# Plugin entry
# --------------------------------------------------------------------------------------

def register(session: ftrack_api.Session, **kw):
    """Register event listener."""
    if not isinstance(session, ftrack_api.Session):
        return
    handle = functools.partial(status_changes_event_listener, session)
    # Lower priority number = higher priority. 20 matches your original.
    session.event_hub.subscribe("topic=ftrack.update", handle, priority=20)
    logger.info("manage_status_change: registered.")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    session = ftrack_api.Session(auto_connect_event_hub=True)
    register(session)
    logger.info("Listening for events. Ctrl-C to abort.")
    session.event_hub.wait()
