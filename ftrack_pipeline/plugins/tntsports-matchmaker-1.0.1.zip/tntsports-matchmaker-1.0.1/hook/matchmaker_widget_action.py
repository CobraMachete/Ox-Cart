# :coding: utf-8
import logging
import json
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from urllib.parse import quote, urlencode
from typing import Any, Dict, Optional, List, Tuple

import ftrack_api
from ftrack_action_handler.action import BaseAction

# ---------- CONFIG ----------
DATA_PARENT_NAME = '0000_DATA'
TEAMS_TASK_NAME = 'ALL_TEAMS'
STRUCTURE_TASK_NAME = 'MATCHMAKER_STRUCTURE'

WIDGET_URL   = 'https://cobramachete.github.io/Ox-Cart/matchmaker'
WIDGET_TITLE = 'MatchMaker'
WIDGET_WIDTH = 1280
WIDGET_HEIGHT = 800

ALLOWED_TYPES_DISCOVER = ('Production',)   # real 1-item tuples
ALLOWED_TYPES_LAUNCH   = ('Production',)
# ---------------------------
def _short(v, n=140):
    s = str(v)
    return s if len(s) <= n else s[:n] + '…'

def _resolve_selection(event) -> Tuple[Optional[str], Optional[str], dict]:
    """Return (etype, eid, raw_item) from first selection item, supporting entityId or entityKey."""
    sel = (event.get('data') or {}).get('selection') or []
    if not sel:
        return None, None, {}
    item = sel[0]
    etype = item.get('entityType')
    eid   = item.get('entityId')
    # Fallback to entityKey: ["Type","uuid"]
    if (not etype or not eid) and 'entityKey' in item:
        try:
            key = item['entityKey']
            if isinstance(key, (list, tuple)) and len(key) == 2:
                etype, eid = key[0], key[1]
        except Exception:
            pass
    return etype, eid, item

def _latest_component_from_data_parent(
    session: ftrack_api.Session,
    data_parent: Dict[str, Any],
    task_name: str,
    logger: logging.Logger
) -> Tuple[Optional[str], List[str]]:
    """
    Given a data parent Context (e.g., 0000_DATA under the selection),
    return (component_id, [urls...]) from the latest AssetVersion on the named Task.
    """
    try:
        if not data_parent:
            return None, []

        data_parent_id = data_parent.get('id')
        q_task = (
            f'Task where name is "{task_name}" and parent_id is "{data_parent_id}"'
        )
        task = session.query(q_task).first()
        if not task:
            logger.warning(f'No Task "{task_name}" under data parent {data_parent_id}')
            return None, []

        q_ver = f'AssetVersion where task_id is "{task["id"]}" and is_latest_version is True'
        version = session.query(q_ver).first()
        if not version:
            logger.warning(f'No latest AssetVersion on task "{task_name}" ({task["id"]})')
            return None, []

        comps = version.get('components') or []
        if not comps:
            logger.warning(f'No components on latest version for task "{task_name}"')
            return None, []

        comp = comps[0]
        comp_id = comp.get('id')

        urls: List[str] = []
        for loc in (comp.get('component_locations') or []):
            url = (((loc or {}).get('url') or {}).get('value'))
            if url:
                urls.append(url)

        if not urls:
            logger.info(
                f'No direct URLs exposed for "{task_name}" (component_id={comp_id}); '
                f'client should resolve via API using credentials.'
            )

        return comp_id, urls

    except Exception as e:
        logger.exception(f'Error collecting component/URLs for task "{task_name}": {e}')
        return None, []


def _find_data_parent_under(
    session: ftrack_api.Session,
    selected_context_id: str,
    project_id: str,
    data_parent_name: str,
    logger: logging.Logger
) -> Optional[Dict[str, Any]]:
    """
    Return the Context (e.g., Folder/TypedContext) named `data_parent_name`
    that is a *descendant* of the selected context.
    """
    try:
        # Constrain by both name + project + descendant-of selection.
        q = (
            'Organizer where name is "{name}" and project_id is "{proj}" '
            'and ancestors any (id is "{sel}")'
        ).format(name=data_parent_name, proj=project_id, sel=selected_context_id)
        data_parent = session.query(q).first()
        if not data_parent:
            logger.warning(
                'No "{name}" context found under selection {sel} (project {proj}).'
                .format(name=data_parent_name, sel=selected_context_id, proj=project_id)
            )
        return data_parent
    except Exception as e:
        logger.exception(f'Error locating data parent under selection: {e}')
        return None


def _fetch_json_from_url(url: str, logger: logging.Logger, timeout: float = 15.0) -> Optional[Dict[str, Any]]:
    """Fetch JSON from a URL; return dict or None."""
    try:
        if not (url.startswith('http://') or url.startswith('https://') or url.startswith('file://')):
            logger.warning(f'Unsupported URL scheme for JSON fetch: {url}')
            return None

        req = Request(url, headers={'User-Agent': 'MatchMakerWidgetAction/1.0'})
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
        try:
            return json.loads(raw)
        except json.JSONDecodeError as je:
            logger.warning(f'JSON decode failed for {url}: {je}')
            return None
    except HTTPError as he:
        logger.warning(f'HTTPError fetching {url}: {he.code} {he.reason}')
    except URLError as ue:
        logger.warning(f'URLError fetching {url}: {ue.reason}')
    except Exception as e:
        logger.exception(f'Unexpected error fetching {url}: {e}')
    return None


class MatchMakerWidgetAction(BaseAction):
    identifier = 'tntsports.launchmatchmaker.action'
    label = 'MatchMaker'
    description = 'Structured Matchup Creator and Builder'
    icon = 'https://cobramachete.github.io/ftrack_icons/img/matchmaker_icon.png'

    def __init__(self, session):
        super(MatchMakerWidgetAction, self).__init__(session)
        self.logger = logging.getLogger(__name__)

    # ---- Discover ----
    def discover(self, session, entities, event):
        self.logger.info("Discovering MatchMaker")
        user_id = event.get('source', {}).get('user', {}).get('username')
        curr_user = session.api_user
        if user_id != curr_user:
            return False

        etype, eid, raw = _resolve_selection(event)
        self.logger.debug(f"Selection (discover): etype={etype} eid={eid} raw={_short(raw)}")
        if not eid:
            return False

        try:
            # Resolve minimally, no deep relation walks.
            entity = session.get('TypedContext', eid)
            if not entity:
                return False
            obj_type = (entity.get('object_type') or {}).get('name')  # may be None on some roots/projects
            self.logger.info(f"Discover entity: {eid} type={obj_type} etype={etype}")
            return (obj_type in ALLOWED_TYPES_DISCOVER) or (etype in ('Project',))  # allow Projects if needed
        except Exception as e:
            self.logger.warning(f'Error in discover fetching entity: {e}')
            return False


    # ---- Launch ----
    def launch(self, session, entities, event):
        if (event.get('data') or {}).get('actionIdentifier') != self.identifier:
            self.logger.info('Ignored launch event not meant for this action.')
            # Return a benign result so the UI doesn't choke:
            return {'success': False, 'message': 'Not my action.'}

        etype, eid, raw = _resolve_selection(event)
        self.logger.debug(f"Selection (launch): etype={etype} eid={eid} raw={_short(raw)}")
        if not eid:
            return {'success': False, 'message': 'Missing entity id in selection.'}

        try:
            entity = session.get('TypedContext', eid)  # keep it minimal; avoid touching heavy relations here
            if not entity:
                return {'success': False, 'message': f'Failed to resolve entity: {etype}:{eid}'}

            obj_type = (entity.get('object_type') or {}).get('name')
            if obj_type not in ALLOWED_TYPES_LAUNCH and etype != 'Project':
                return {'success': False, 'message': f'Unsupported type: {obj_type or etype}'}

            project_id = entity.get('project_id') or (entity.get('id') if etype == 'Project' else None)
            if not project_id:
                return {'success': False, 'message': 'Entity missing project_id.'}
            
            # Find the *scoped* 0000_DATA under the selected entity
            data_parent = _find_data_parent_under(
                session=session,
                selected_context_id=eid,           # the selected entity id
                project_id=project_id,
                data_parent_name=DATA_PARENT_NAME,
                logger=self.logger
            )

            # Resolve latest components from that specific 0000_DATA
            teams_comp_id, teams_urls = _latest_component_from_data_parent(
                session, data_parent, TEAMS_TASK_NAME, self.logger
            )
            struct_comp_id, struct_urls = _latest_component_from_data_parent(
                session, data_parent, STRUCTURE_TASK_NAME, self.logger
            )


            self.logger.info(f'Launching MatchMaker for {eid} (obj_type={obj_type} etype={etype})')

            params = {
                'entity_id': eid or '',
                'project_id': project_id or '',
                'teams_comp': teams_comp_id or '',
                'struct_comp': struct_comp_id or '',
                'teams_url': (teams_urls[0] if teams_urls else ''),
                'structure_url': (struct_urls[0] if struct_urls else '')
            }
            self.logger.info(f'MatchMaker seed (hash params): ' + json.dumps({k:_short(v) for k,v in params.items()}))

            from urllib.parse import urlencode
            seed_url = f'{WIDGET_URL}#{urlencode(params, doseq=False, safe="")}'

            return {
                'success': True,
                'message': 'success',
                'type': 'widget',
                'url': seed_url,
                'title': WIDGET_TITLE,
                'width': WIDGET_WIDTH,
                'height': WIDGET_HEIGHT
            }

        except Exception as e:
            self.logger.exception(f'Error in launch: {e}')
            return {'success': False, 'message': f'Unexpected error: {e}'}



def register(session, **kw):
    if not isinstance(session, ftrack_api.Session):
        return
    action = MatchMakerWidgetAction(session)
    action.register()
    logging.info("MatchMakerWidgetAction registered successfully!")


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    session = ftrack_api.Session(auto_connect_event_hub=True)
    register(session)
    session.event_hub.wait()
