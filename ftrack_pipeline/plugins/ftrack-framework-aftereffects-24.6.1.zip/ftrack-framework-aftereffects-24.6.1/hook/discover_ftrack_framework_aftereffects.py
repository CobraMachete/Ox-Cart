# :coding: utf-8
# :copyright: Copyright (c) 2024 ftrack

import os
import ftrack_api
import logging
import functools
import uuid
import sys
import subprocess
import platform
import threading
import time

from datetime import datetime
from ftrack_utils.version import get_connect_plugin_version
from ftrack_api.entity.location import Location
from ftrack_api.structure.standard import StandardStructure
from ftrack_api.accessor.disk import DiskAccessor
import ftrack_api.event.base
from ftrack_api.resource_identifier_transformer.base import ResourceIdentifierTransformer



# The name of the integration, should match name in launcher.
NAME = 'framework-aftereffects'

logger = logging.getLogger(__name__)
logger = logging.getLogger("ftrack_connect.launch_javascript_rpc")

cwd = os.path.dirname(__file__)
connect_plugin_path = os.path.abspath(os.path.join(cwd, '..'))

# Read version number from __version__.py
__version__ = get_connect_plugin_version(connect_plugin_path)

python_dependencies = os.path.join(connect_plugin_path, 'dependencies')

session_risid = None


def on_discover_integration(session, event):        
    data = {
        'integration': {
            'name': NAME,
            'version': __version__,
            'icon': 'https://cobramachete.github.io/ftrack_icons/img/aftereffects.png'
            
        }
    }

    return data


def on_launch_integration(session, event):

    '''Handle application launch and add environment to *event*.'''

    session.reset()

    launch_data = {'integration': event['data']['integration']}

    discover_data = on_discover_integration(session, event)

    for key in discover_data['integration']:
        launch_data['integration'][key] = discover_data['integration'][key]

    integration_version = event['data']['application']['version'].version[0]

    logger.info(
        f'Launching integration v{integration_version} assuming CEP plugin has '
        'been properly installed prior to launch.'
    )

    if not launch_data['integration'].get('env'):
        launch_data['integration']['env'] = {}

    launch_data['integration']['env']['PYTHONPATH.prepend'] = os.path.pathsep.join([python_dependencies])

    launch_data['integration']['env']['FTRACK_REMOTE_INTEGRATION_SESSION_ID'] = str(uuid.uuid4())

    global session_risid
    session_risid = launch_data['integration']['env']['FTRACK_REMOTE_INTEGRATION_SESSION_ID']

    launch_data['integration']['env']['FTRACK_AFTEREFFECTS_VERSION'] = str(
        integration_version
    )

    selection = event['data'].get('context', {}).get('selection', [])
    

    if selection:
        task = session.get('Context', selection[0]['entityId'])

        shot_details = get_shot_details(session, task)
        logger.debug(shot_details)

        # NEED TO THROW ERROR HERE IF DOES NOT RETURN SHOT
        if shot_details is not None:
            launch_data['integration']['env']['FTRACK_SHOTNAME.set'] = shot_details[0]
            launch_data['integration']['env']['FTRACK_SHOTID.set'] = shot_details[1]
        
        
        # GRABBING TEAMS ANDS MULTICOMP OBJECT DETAILS
        teams_details = get_teamsobj_details(session, task)
        multicomp_details = get_multicompobj_details(session, task)
        

        teams_container_task = None
        teams_container_status = None

        multicomp_container_task = None
        multicomp_container_status = None

        if teams_details is not None:

            teams_container_task = create_container_task(session, teams_details, shot_details, 'Teams')
            teams_container_status = teams_container_task['status']['name']
            logger.debug(teams_container_task['name'])
            logger.debug(teams_container_task['id'])
            logger.debug(teams_container_task['parent']['name'])

            launch_data['integration']['env']['FTRACK_TEAMSNAME.set'] = teams_details[0]
            launch_data['integration']['env']['FTRACK_TEAMSID.set'] = teams_details[1]
            launch_data['integration']['env']['FTRACK_TEAMSTASKNAME.set'] = teams_container_task['name']
            launch_data['integration']['env']['FTRACK_TEAMSTASKID.set'] = teams_container_task['id']

            launch_data['integration']['env']['FTRACK_MULTICOMPNAME.set'] = 'None'
            launch_data['integration']['env']['FTRACK_MULTICOMPID.set'] = 'None'
            launch_data['integration']['env']['FTRACK_MULTICOMPTASKNAME.set'] = 'None'
            launch_data['integration']['env']['FTRACK_MULTICOMPTASKID.set'] = 'None'

        elif multicomp_details is not None:
            
            multicomp_container_task = create_container_task(session, multicomp_details, shot_details, 'Multicomp')
            multicomp_container_status = multicomp_container_task['status']['name']
            logger.debug(multicomp_container_task['name'])
            logger.debug(multicomp_container_task['id'])
            logger.debug(multicomp_container_task['parent']['name'])

            launch_data['integration']['env']['FTRACK_MULTICOMPNAME.set'] = multicomp_details[0]
            launch_data['integration']['env']['FTRACK_MULTICOMPID.set'] = multicomp_details[1]
            launch_data['integration']['env']['FTRACK_MULTICOMPTASKNAME.set'] = multicomp_container_task['name']
            launch_data['integration']['env']['FTRACK_MULTICOMPTASKID.set'] = multicomp_container_task['id']

            # NULLING OUT TEAMS ITEMS
            launch_data['integration']['env']['FTRACK_TEAMSNAME.set'] = 'None'
            launch_data['integration']['env']['FTRACK_TEAMSID.set'] = 'None'
            launch_data['integration']['env']['FTRACK_TEAMSTASKNAME.set'] = 'None'
            launch_data['integration']['env']['FTRACK_TEAMSTASKID.set'] = 'None'

        else:
            # NULLING OUT TEAMS ITEMS
            launch_data['integration']['env']['FTRACK_TEAMSNAME.set'] = 'None'
            launch_data['integration']['env']['FTRACK_TEAMSID.set'] = 'None'
            launch_data['integration']['env']['FTRACK_TEAMSTASKNAME.set'] = 'None'
            launch_data['integration']['env']['FTRACK_TEAMSTASKID.set'] = 'None'

            # NULLING OUT MULTICOMP ITEMS
            launch_data['integration']['env']['FTRACK_MULTICOMPNAME.set'] = 'None'
            launch_data['integration']['env']['FTRACK_MULTICOMPID.set'] = 'None'
            launch_data['integration']['env']['FTRACK_MULTICOMPTASKNAME.set'] = 'None'
            launch_data['integration']['env']['FTRACK_MULTICOMPTASKID.set'] = 'None'

        team_descendants = []
        multicomp_descendants = []
        
        if teams_details is not None:
            
            curr_teams_obj = session.get('Teams', teams_details[1])
            task_descendants = curr_teams_obj['descendants']
            

            for descendant in task_descendants:
                temptask = session.get('Task', descendant['id'])
                descendantpair = [descendant['name'], descendant['id'], temptask['status']['name']]
                team_descendants.append(descendantpair)
            
            
            launch_data['integration']['env']['FTRACK_SIBLINGTASKS.set'] = team_descendants
            launch_data['integration']['env']['FTRACK_FOLDERNAME.set'] = curr_teams_obj['parent']['name']
            launch_data['integration']['env']['FTRACK_FOLDERID.set'] = curr_teams_obj['parent']['id']

            launch_data['integration']['env']['FTRACK_TEAMSTHUMBID.set'] = curr_teams_obj['thumbnail_id']
            launch_data['integration']['env']['FTRACK_TEAMSTHUMBURL.set'] = curr_teams_obj['thumbnail_url']['url']

            launch_data['integration']['env']['FTRACK_MULTICOMPTHUMBID.set'] = 'None'
            launch_data['integration']['env']['FTRACK_MULTICOMPTHUMBURL.set'] = 'None'

        elif multicomp_details is not None:
            
            curr_multicomp_obj = session.get('Multicomp', multicomp_details[1])
            task_descendants = curr_multicomp_obj['descendants']
            

            for descendant in task_descendants:
                temptask = session.get('Task', descendant['id'])
                descendantpair = [descendant['name'], descendant['id'], temptask['status']['name']]
                multicomp_descendants.append(descendantpair)
            
            
            launch_data['integration']['env']['FTRACK_SIBLINGTASKS.set'] = multicomp_descendants
            launch_data['integration']['env']['FTRACK_FOLDERNAME.set'] = curr_multicomp_obj['parent']['name']
            launch_data['integration']['env']['FTRACK_FOLDERID.set'] = curr_multicomp_obj['parent']['id']

            launch_data['integration']['env']['FTRACK_MULTICOMPTHUMBID.set'] = curr_multicomp_obj['thumbnail_id']
            launch_data['integration']['env']['FTRACK_MULTICOMPTHUMBURL.set'] = curr_multicomp_obj['thumbnail_url']['url']

            launch_data['integration']['env']['FTRACK_TEAMSTHUMBID.set'] = 'None'
            launch_data['integration']['env']['FTRACK_TEAMSTHUMBURL.set'] = 'None'

        else:

            launch_data['integration']['env']['FTRACK_SIBLINGTASKS.set'] = None
            
            taskobj = session.get('Task', task['id'])
            launch_data['integration']['env']['FTRACK_FOLDERNAME.set'] = taskobj['parent']['name']
            launch_data['integration']['env']['FTRACK_FOLDERID.set'] = taskobj['parent']['id']

            # NULLING OUT TEAMS ITEMS
            launch_data['integration']['env']['FTRACK_TEAMSTHUMBID.set'] = None
            launch_data['integration']['env']['FTRACK_TEAMSTHUMBURL.set'] = None

            # NULLING OUT MULTICOMP ITEMS
            launch_data['integration']['env']['FTRACK_MULTICOMPTHUMBID.set'] = None
            launch_data['integration']['env']['FTRACK_MULTICOMPTHUMBURL.set'] = None


        logger.debug("/////////////////////////////////////////   DESCENDANTS    ///////////////////////////////////////")
        logger.debug(team_descendants)
        logger.debug(multicomp_descendants)

        # SEARCHING FOR PUBLISHED AE FILES ATTACHED TO TASK
        if teams_details is not None:
            newest_ae = get_latest_ae_project(session, task, shot_details, teams_details, teams_container_task, multicomp_details, multicomp_container_task)

        if multicomp_details is not None:
            newest_ae = get_latest_ae_project(session, task, shot_details, multicomp_details, multicomp_container_task, multicomp_details, multicomp_container_task)

        if multicomp_details is None and teams_details is None:
            newest_ae = get_latest_ae_project(session, task, shot_details, multicomp_details, multicomp_container_task, multicomp_details, multicomp_container_task)
        

        logger.info(newest_ae)

        if newest_ae is not None:
            launch_data['integration']['launch_arguments'] = [newest_ae]
            launch_data['integration']['env']['FTRACK_AEPROJTYPE.set'] = 'Version'
            

        # SEARCHING FOR POSSIBLE PROJECT FROM SIBLING TASK
        tskprj = task['project']['name']
        

        teams_ae = check_for_teams_project(task, shot_details, teams_details, task['link'], tskprj)
        logger.debug(teams_ae)

        if newest_ae is None:
            if teams_ae is not None:
                launch_data['integration']['launch_arguments'] = [teams_ae]
                launch_data['integration']['env']['FTRACK_AEPROJTYPE.set'] = 'Version'


        multicomp_ae = check_for_multicomp_project(task, shot_details, multicomp_details, task['link'], tskprj)
        logger.debug(multicomp_ae)

        if newest_ae is None:
            if teams_ae is None:
                if multicomp_ae is not None:
                    launch_data['integration']['launch_arguments'] = [multicomp_ae]
                    launch_data['integration']['env']['FTRACK_AEPROJTYPE.set'] = 'Version'


        # SEARCHING FOR TEMPLATE AE FILES
        template_ae = check_for_ae_template(session, task, shot_details, teams_details, multicomp_details, task['link'], tskprj)
        logger.debug(template_ae)

        if newest_ae is None:
            if teams_ae is None:
                if multicomp_ae is None:
                    if template_ae is not None:
                        launch_data['integration']['launch_arguments'] = [template_ae]
                        launch_data['integration']['env']['FTRACK_AEPROJTYPE.set'] = 'Template'


        # SEARCHING FOR GLOBAL TEMPLATE AE FILES
        template_global_ae = check_for_global_ae_template(session, task, shot_details, teams_details, multicomp_details, task['link'], tskprj)
        logger.debug(template_global_ae)

        #  SETTING AE PROJECT AS GLOBAL AE
        if newest_ae is None:
            if teams_ae is None:
                if multicomp_ae is None:
                    if template_ae is None:
                        if template_global_ae is not None:
                            launch_data['integration']['launch_arguments'] = [template_global_ae]
                            launch_data['integration']['env']['FTRACK_AEPROJTYPE.set'] = 'Template'



        #  IF NONE OF THE TEMPLATE OR PUBLISHED FILE CRITERIA ARE MET OPEN AE WITH NOTHING
        if newest_ae is None and teams_ae is None and multicomp_ae is None and template_ae is None and template_global_ae is None:
            launch_data['integration']['env']['FTRACK_AEPROJTYPE.set'] = 'None'

        #  HANDLING STATUS CHANGE
        prjschema = task['project']['project_schema']['name']
        change_task_status(session, task['id'], 'In Progress', prjschema, team_descendants, teams_container_task)

        # GETTING LIST OF TASK STATUSES
        avail_task_statuses = get_status_list(session, prjschema)
        logger.debug(avail_task_statuses)
        
        launch_data['integration']['env']['FTRACK_CONTEXTID.set'] = task['id']
        launch_data['integration']['env']['FTRACK_CONTEXTNAME.set'] = task['name']
        launch_data['integration']['env']['FTRACK_CONTEXTLINK.set'] = task['link']
        launch_data['integration']['env']['FTRACK_CONTEXTPRJID.set'] = task['project_id']
        launch_data['integration']['env']['FTRACK_CONTEXTTHUMBID.set'] = task['thumbnail_id']
        launch_data['integration']['env']['FTRACK_CONTEXTTHUMBURL.set'] = task['thumbnail_url']['url']
        launch_data['integration']['env']['FTRACK_CONTEXTPARENTNAME.set'] = task['parent']['name']
        launch_data['integration']['env']['FTRACK_CONTEXTPARENTID.set'] = task['parent']['id']
        launch_data['integration']['env']['FTRACK_CONTEXTPARENTTYPE.set'] = task['parent']['context_type']

        if teams_details is not None:

            launch_data['integration']['env']['FTRACK_CONTEXTTASKSTATUS.set'] = teams_container_task['status']['name']

        elif multicomp_details is not None:

            launch_data['integration']['env']['FTRACK_CONTEXTTASKSTATUS.set'] = multicomp_container_task['status']['name']

        else:

            launch_data['integration']['env']['FTRACK_CONTEXTTASKSTATUS.set'] = task['status']['name']
            
        launch_data['integration']['env']['FTRACK_CONTEXTAVAILSTATUSES.set'] = avail_task_statuses

        # ADDING USERNAME TO ENV
        curusr = session.api_user
        theusr = session.query('User where username is "{0}"'.format(curusr)).one()
        
        launch_data['integration']['env']['FTRACK_CONTEXTUSRNAME.set'] = curusr
        launch_data['integration']['env']['FTRACK_CONTEXTUSRNAMEID.set'] = theusr

        
    
    return launch_data

def check_for_teams_project(currtask, currshot, currteam, link, prjname):

    if platform.system() == "Windows":
        DISK_PREF = 'T:/wfh'
    else:
        DISK_PREF = '/Volumes/tscreative/wfh'

    shot_fullname = currshot[0]
    shot_namenum = shot_fullname.split('_')[0]

    if currteam is None:
        ae_prj_name = shot_namenum + '_' + currtask['name'] + '.aep'
        
    else:
        ae_prj_name = shot_namenum + '_' + currteam[0] + '.aep'

    path_parts = []
    path_parts.append(prjname)
    structure_names = [item['name'] for item in link[1:-1]]
    logger.debug(structure_names)
    # structure_names.append('02_cmp')
    structure_names.append(ae_prj_name)

    path_parts.extend(structure_names)
    logger.debug(path_parts)

    teams_basepath = os.path.join(DISK_PREF, *path_parts)
    teams_ae_project = teams_basepath.replace('\\', '/')
    logger.debug(teams_ae_project);

    if os.path.exists(teams_ae_project):
        return teams_ae_project
    else:
        return None

def check_for_multicomp_project(currtask, currshot, currmulticomp, link, prjname):

    if platform.system() == "Windows":
        DISK_PREF = 'T:/wfh'
    else:
        DISK_PREF = '/Volumes/tscreative/wfh'

    shot_fullname = currshot[0]
    shot_namenum = shot_fullname.split('_')[0]

    if currmulticomp is None:
        ae_prj_name = shot_namenum + '_' + currtask['name'] + '.aep'
        
    else:
        ae_prj_name = shot_namenum + '_' + currmulticomp[0] + '.aep'

    path_parts = []
    path_parts.append(prjname)
    structure_names = [item['name'] for item in link[1:-1]]
    logger.debug(structure_names)
    # structure_names.append('02_cmp')
    structure_names.append(ae_prj_name)

    path_parts.extend(structure_names)
    logger.debug(path_parts)

    multicomp_basepath = os.path.join(DISK_PREF, *path_parts)
    multicomp_ae_project = multicomp_basepath.replace('\\', '/')
    logger.debug(multicomp_ae_project);

    if os.path.exists(multicomp_ae_project):
        return multicomp_ae_project
    else:
        return None

def check_for_ae_template(session, currtask, currshot, currteam, currmulticomp, link, prjname):

    if platform.system() == "Windows":
        DISK_PREF = 'T:/wfh'
    else:
        DISK_PREF = '/Volumes/tscreative/wfh'

    shot_fullname = currshot[0]
    shot_namenum = shot_fullname.split('_')[0]

    if currteam is not None:
        
        ae_prj_name = shot_namenum + '_' + currteam[0] + '_TEMPLATE' + '.aep'

    elif currmulticomp is not None:
        
        ae_prj_name = shot_namenum + '_' + currmulticomp[0] + '_TEMPLATE' + '.aep' 

    else:
        ae_prj_name = shot_namenum + '_TEMPLATE' + '.aep'

    path_parts = []
    path_parts.append(prjname)

    if currteam is not None:
        structure_names = [item['name'] for item in link[1:-2]]
    
    elif currmulticomp is not None:
        structure_names = [item['name'] for item in link[1:-2]]

    else:
        structure_names = [item['name'] for item in link[1:-1]]
        
    logger.debug(structure_names)
    # structure_names.append('02_cmp')
    structure_names.append('_TEMPLATE')
    structure_names.append(ae_prj_name)

    path_parts.extend(structure_names)
    logger.debug(path_parts)

    template_basepath = os.path.join(DISK_PREF, *path_parts)
    template_ae_project = template_basepath.replace('\\', '/')
    logger.debug(template_ae_project);

    if os.path.exists(template_ae_project):
        return template_ae_project
    else:
        return None

def get_latest_ae_project(session, currtask, currshot, currteam, teams_container, currmulticomp, multicomp_container):

    shot_fullname = currshot[0]
    shot_namenum = shot_fullname.split('_')[0]

    if currteam is not None:
        
        ae_prj_name = shot_namenum + '_' + currteam[0] + '.aep'

    elif currmulticomp is not None:
        
        ae_prj_name = shot_namenum + '_' + currmulticomp[0] + '.aep'
        
    else:
        ae_prj_name = shot_namenum + '_' + currtask['name'] + '.aep'
        

    if teams_container is not None:
        
        get_latest_ae = session.query('AssetVersion where task.id is {0} and asset.type.short is "aep" and is_latest_version is True'.format(teams_container['id'])).first()

    elif multicomp_container is not None:
        
        get_latest_ae = session.query('AssetVersion where task.id is {0} and asset.type.short is "aep" and is_latest_version is True'.format(multicomp_container['id'])).first()

    else:
        get_latest_ae = session.query('AssetVersion where task.id is {0} and asset.type.short is "aep" and is_latest_version is True'.format(currtask['id'])).first()



    if get_latest_ae is None:
        return None
    else:
        
        merged_ae_prj_path = None
        

        for component in get_latest_ae['components']:

            if component['file_type'] == ".aep":
                ae_component = component

                for elements in ae_component['component_locations']:

                    compo = elements['component']
                    loc = elements['location']
                    
                    basepath = loc.get_filesystem_path(compo)
                    basepathsplit = basepath.split('_archive')[0]

                    latest_ae_prj_path = basepathsplit.replace('\\', '/')
                    merged_ae_prj_path = os.path.join(latest_ae_prj_path, ae_prj_name)
                    # template_ae_prj_path = os.path.join(latest_ae_prj_path, '_TEMPLATE', ae_template_name)

                    
                    if os.path.exists(merged_ae_prj_path):
                        continue
                    else:
                        merged_ae_prj_path = None

        
        return merged_ae_prj_path

def check_for_global_ae_template(session, currtask, currshot, currteam, currmulticomp, link, prjname):

    if platform.system() == "Windows":
        DISK_PREF = 'T:/wfh'
    else:
        DISK_PREF = '/Volumes/tscreative/wfh'

    shot_fullname = currshot[0]
    shot_namenum = shot_fullname.split('_')[0]
    shot_num = currshot[0].split('_')[0]

    logger.info(shot_num)
    

    if currteam is not None:
        
        ae_prj_name = shot_num + '_' + 'GLOBAL_TEMPLATE' + '.aep'

    elif currmulticomp is not None:
        
        ae_prj_name = shot_num + '_' + 'GLOBAL_TEMPLATE' + '.aep' 

    else:
        ae_prj_name = shot_num + '_GLOBAL_TEMPLATE' + '.aep'

    path_parts = []
    path_parts.append(prjname)

    if currteam is not None:
        structure_names = [item['name'] for item in link[1:-2]]
    
    elif currmulticomp is not None:
        structure_names = [item['name'] for item in link[1:-2]]

    else:
        structure_names = [item['name'] for item in link[1:-1]]
        
    logger.debug(structure_names)
    # structure_names.append('02_cmp')
    structure_names.append('_TEMPLATE')
    structure_names.append(ae_prj_name)

    path_parts.extend(structure_names)
    logger.debug(path_parts)

    template_basepath = os.path.join(DISK_PREF, *path_parts)
    template_global_ae_project = template_basepath.replace('\\', '/')
    logger.debug(template_global_ae_project);

    if os.path.exists(template_global_ae_project):
        return template_global_ae_project
    else:
        return None
                 
def get_shot_details(session, currtask):

    shotinfo = []
    
    ids = [item['id'] for item in currtask['link']]

    for item in ids:

        theshot = session.get('Shot', item)

        if theshot is not None:
            shotinfo.append(theshot['name'])
            shotinfo.append(theshot['id'])
            return shotinfo
    
    if len(shotinfo) == 0:
        return None

def get_teamsobj_details(session, currtask):

    teamsinfo = []
    
    ids = [item['id'] for item in currtask['link']]

    for item in ids:

        teamsobj = session.get('Teams', item)

        if teamsobj is not None:

            teamsinfo.append(teamsobj['name'])
            teamsinfo.append(teamsobj['id'])
            return teamsinfo
    
    if len(teamsinfo) == 0:
        return None

def get_multicompobj_details(session, currtask):

    multicompinfo = []
    
    ids = [item['id'] for item in currtask['link']]

    for item in ids:

        multicompobj = session.get('Multicomp', item)

        if multicompobj is not None:

            multicompinfo.append(multicompobj['name'])
            multicompinfo.append(multicompobj['id'])
            return multicompinfo
    
    if len(multicompinfo) == 0:
        return None

def change_task_status(session, task_id, new_status, prj_schema, siblings, task_container):

    available_stats = {}
    logger.debug(siblings)
    task = session.get('Task', task_id)

    comptask_type_id = session.query('Task where type.name is "Comp"')[0]["type"]["id"]

    # QUERY THE PROJECT SCHEMA
    project_schema = session.query(
        'ProjectSchema where name is "{}"'.format(prj_schema)
    ).one()

    # GET TASK STATUSES FROM THE PROJECT SCHEMA
    task_statuses = project_schema.get_statuses(
        schema = "Task",
        type_id = comptask_type_id
    )

    statusref = task['status']['name'].lower()

    if statusref in ('not started', 'ready to start'):

        try:

            status = session.query(
                'Status where name is "{}"'.format(new_status)
            ).first()

            if status:
                task['status'] = status
                session.commit()
                print("Task status updated successfully.")

                if siblings is not None:
                    for item in siblings:
                        sibtask = session.get('Task', item[1])
                        if sibtask is not None:
                            sibtask['status'] = status
                session.commit()
            else:
                print("Status not found: {}".format(new_status))

        except Exception as e:
            print("Error updating task status: {}".format(str(e)))


def update_task_status(session, event):

    new_status = "In Progress"
    task_id = event['data']['ae_info']['TASK_ID']
    
    task = session.get('Task', task_id)

    statusref = task['status']['name'].lower()

    if statusref == 'not started' or statusref == 'ready to start':

        try:

            status = session.query(
                'Status where name is "{}"'.format(new_status)
            ).first()

            if status:
                task['status'] = status
                session.commit()
                print("Task status updated successfully.")
                return {"success": True, "msg": "Task Updated Successfully!"}
            else:
                print("Status not found: {}".format(new_status))
                return {"success": False, "msg": "Status Not Found!"}

        except Exception as e:
            
            print("Error updating task status: {}".format(str(e)))
            return {"success": False, "msg": str(e)}


def update_task_status_group(session, event):

    logger.info('UPDATING TASK GROUP STATUSES')
    logger.info(event)

    responsearr = []
    

    task_ids = event['data']['ae_info']['TASK_IDS']
    logger.info(task_ids)

    # task = session.get('Task', '6691233e-d4b0-4ffe-90f7-791edbf8d4da')
    # logger.info(task)

    for task_id in task_ids:

        currtaskid = task_id[0]
        newstat = task_id[1]
        currtask = session.get('Task', task_id[0])
        

        logger.info('------------------------------------------------     THE CURRENT TASK AND PROPOSED STATUS ARE     -------------------------------------------------')
        logger.info(task_id[0])
        logger.info(newstat)
        logger.info(currtask)

        try:
            status = session.query(
                'Status where name is "{}"'.format(newstat)
            ).first()

            if status:

                currtask['status'] = status
                session.commit()

                successtmparr = []

                successtmparr.append(currtaskid)
                successtmparr.append(newstat)
                successtmparr.append(True)

                responsearr.append(successtmparr)

                logger.info("Task {0} status successfully updated to {1}".format(currtask['name'], newstat))

                logger.info(responsearr)
                return {"success": True, "msg": "AE Published!"}
                

                
            else:

                failedtmparr = []

                failedtmparr.append(currtaskid)
                failedtmparr.append(newstat)
                failedtmparr.append(False)

                responsearr.append(failedtmparr)

                logger.info("Task {0} status failed to update to {1}".format(currtask['name'], newstat))

                logger.info(responsearr)
                return {"success": False, "msg": "Unable to update status"}
                
                

        except Exception as e:
            
            # errortmparr = [];
            # errortmparr.append(e)
            # responsearr.append(errortmparr)
            logger.info("Error updating task status: {}".format(str(e)))
            return {"success": False, "msg": str(e)}
        
    return responsearr
            

def check_teams_container(session, event):

    logger.info('INSIDE CHECK TEAMS CONTAINER')
    par_id = event['data']['ae_info']['PARENT_TASK_ID']
    cont_name = event['data']['ae_info']['TEAMS_CONT_NAME']
    found_container = False
    existing_container = ""
    logger.info('=================================      STEP 1')

    task_type_name = 'Container'
    tsk_type = session.query('Type where name is {0}'.format(task_type_name)).first()

    logger.info('=================================      STEP 2')

    teams = session.get('Teams', par_id)
    team_desc = teams['descendants']
    logger.info(team_desc)

    logger.info('=================================      STEP 3')

    for itm in team_desc:
        if itm['name'] == cont_name:
            found_container = True
            existing_container = itm['id']
            logger.info(existing_container)


    logger.info('=================================      FOUND CONTAINER IS')
    logger.info(found_container)

    if found_container is False:

        try:

            # CREATE NEW CONTAINER ITEM
            new_cont = session.create('Task', {
                'parent': teams,
                'name': cont_name,
                'type': tsk_type
            })

            session.commit()
            session.reset()
            return {"success": True, "msg": new_cont['id']}
            
        
        except Exception as e:
            
            print("Error updating task status: {}".format(str(e)))
            return {"success": False, "msg": "Container Error!"}
        
    else:
        return {"success": True, "msg": existing_container}
        

def check_multicomp_container(session, event):

    
    par_id = event['data']['ae_info']['PARENT_TASK_ID']
    cont_name = event['data']['ae_info']['MULTICOMP_CONT_NAME']
    found_container = False
    existing_container = ""
    logger.info('=================================      STEP 1')

    task_type_name = 'Container'
    tsk_type = session.query('Type where name is {0}'.format(task_type_name)).first()

    logger.info('=================================      STEP 2')

    multicomps = session.get('Multicomp', par_id)
    multicomp_desc = multicomps['descendants']
    logger.info(multicomp_desc)

    logger.info('=================================      STEP 3')

    for itm in multicomp_desc:
        if itm['name'] == cont_name:
            found_container = True
            existing_container = itm['id']
            logger.info(existing_container)


    logger.info('=================================      FOUND CONTAINER IS')
    logger.info(found_container)

    if found_container is False:

        try:

            # CREATE NEW CONTAINER ITEM
            new_cont = session.create('Task', {
                'parent': multicomps,
                'name': cont_name,
                'type': tsk_type
            })

            session.commit()
            session.reset()
            return {"success": True, "msg": new_cont['id']}
        
        except Exception as e:
            
            print("Error updating task status: {}".format(str(e)))
            return {"success": False, "msg": "Container Error"}
        
    else:
        return {"success": True, "msg": existing_container}
        

def update_prj_status(session, task_id, new_status):

    task = session.get('Task', task_id)

    try:

        status = session.query(
            'Status where name is "{}"'.format(new_status)
        ).first()

        if status:
            task['status'] = status
            session.commit()
            
        else:
            logger.info("Status not found: {}".format(new_status))

    except Exception as e:
        logger.info("Error updating task status: {}".format(str(e)))


# def safe_update_task_status(session, task_id, desired_label_or_short, *, commit=True, logger=None):
#     """
#     Set a Task's status only if the desired status exists for the Task's type
#     in the project's schema. Matches by:
#       - Status.name  (e.g., "In Progress")
#       - State.name   (e.g., "In progress")
#       - State.short  (e.g., "IP")
#     Returns True if set, False if skipped.
#     """
#     log = logger or logging.getLogger(__name__)
#     task = session.get('Task', task_id)
#     if not task:
#         log.warning("safe_update_task_status: task %s not found", task_id)
#         return False

#     label = (desired_label_or_short or "").strip().lower()
#     if not label:
#         log.info("safe_update_task_status: empty desired status; skipping")
#         return False

#     proj_schema = task['project']['project_schema']
#     type_id = task['type']['id']
#     allowed = proj_schema.get_statuses(schema="Task", type_id=type_id) or []

#     def _norm(s):
#         return (s or "").strip().lower()

#     target = None
#     for st in allowed:
#         if _norm(st['name']) == label:
#             target = st; break
#         if _norm(st['state']['name']) == label:
#             target = st; break
#         if _norm(st['state']['short']) == label:
#             target = st; break

#     if not target:
#         log.warning(
#             "Status %r is not valid for Task %s (type=%s). Allowed: %s",
#             desired_label_or_short, task_id, task['type']['name'],
#             [s['name'] for s in allowed]
#         )
#         return False

#     # Already set?
#     if task['status'] and task['status']['id'] == target['id']:
#         log.info("Task %s already in status %s; skipping", task_id, target['name'])
#         return True

#     task['status'] = target
#     if commit:
#         try:
#             session.commit()
#         except Exception as e:
#             log.exception("Commit failed setting status %r on task %s: %s",
#                           target['name'], task_id, e)
#             raise
#     return True



def update_render_status(session, task_id, new_status):

    task = session.get('Task', task_id)

    try:

        status = session.query(
            'Status where name is "{}"'.format(new_status)
        ).first()

        if status:
            task['status'] = status
            session.commit()
            
        else:
            logger.info("Status not found: {}".format(new_status))

    except Exception as e:
        logger.info("Error updating task status: {}".format(str(e)))

def get_status_list(session, prj_schema):

    available_stats = []

    # Grab a Comp type_id (any Comp task is fine to fetch type_id)
    # (If there might be no Comp tasks at all, add a guard here.)
    comp_type_id = session.query('Task where type.name is "Comp"')[0]["type"]["id"]

    

    # QUERY THE PROJECT SCHEMA
    project_schema = session.query(
        'ProjectSchema where name is "{}"'.format(prj_schema)
    ).one()

    # GET TASK STATUSES FROM THE PROJECT SCHEMA
    task_statuses = project_schema.get_statuses(
        schema = "Task",
        type_id=comp_type_id
    )

    # Build status lookups (dict by status name)
    # task_statuses = {s["name"]: s for s in project_schema.get_statuses(schema="Task", type_id=comp_type_id)}
    

    for stat_names in task_statuses:
        # available_stats[stat_names['id']] = stat_names['name']
        available_stats.append(stat_names['name'])
    
    return available_stats

def create_container_task(session, tmobj, shotobj, objtype):
    shot_split = shotobj[0].split("_")
    cont_prefix = shot_split[0]
    cont_task_name = cont_prefix + '_' + tmobj[0] + '_CONTAINER'

    if (objtype == 'Teams'):
        tm = session.get('Teams', tmobj[1])
        
        task_type_name = 'Container'
        tsk_type = session.query('Type where name is {0}'.format(task_type_name)).first()
        
        gettask = session.query('Task where parent.id is {0} and name is {1}'.format(tmobj[1], cont_task_name)).first()

        if gettask is None:
            new_cont_task = session.create('Task', {
                'name': cont_task_name,
                'type': tsk_type,
                'parent': tm,
                }
            )

            session.commit()

            return new_cont_task
        
        else:

            return gettask

    if (objtype == 'Multicomp'):

        tm = session.get('Multicomp', tmobj[1])
        
        task_type_name = 'Container'
        tsk_type = session.query('Type where name is {0}'.format(task_type_name)).first()
        
        gettask = session.query('Task where parent.id is {0} and name is {1}'.format(tmobj[1], cont_task_name)).first()

        if gettask is None:
            new_cont_task = session.create('Task', {
                'name': cont_task_name,
                'type': tsk_type,
                'parent': tm,
                }
            )

            session.commit()

            return new_cont_task
        
        else:

            return gettask
    

# PRIMARY HANDLER FOR FTRACK TO AE CUSTOM EVENTS
def on_chatterbox_notification(session, event):
    
    ae_processor = ae_function_router(session_risid, session, event)
    
    if ae_processor is True:

        # response = "After Effects file has been successfully published."
        response = ae_processor
        #THIS IS THE OPERATIONAL AND CONSISTENT RETURN
        session.event_hub.publish(ftrack_api.event.base.Event(
            topic='custom.chatterbox.eavesdrop',
            data=response
        ))

    else:

        response = ae_processor
        #THIS IS THE OPERATIONAL AND CONSISTENT RETURN
        session.event_hub.publish(ftrack_api.event.base.Event(
            topic='custom.chatterbox.eavesdrop',
            data=response
        ))



#AE SPECIFIC DATA FUNCTIONS
def ae_function_router(sessid, session, event):

    ae_risid = event['data']['remote_integration_session_id']

    #CHECKING IF SESSION ID SENT FROM AE MATCHES FTRACK CONNECTS
    if ae_risid == sessid:
        
        ae_data = event

        function_request = event['data']['ae_info']['FUNCTION_NAME']

        if function_request == "publish_env_ae_task":

            publish_curr_task = publish_ae_file(session, event)
            return publish_curr_task
            
        elif function_request == "publish_global_template_ae_task":

            publish_globtemp_task = publish_global_template_file(session, event)
            return publish_globtemp_task

        elif function_request == "publish_review_mov_task":

            publish_review_task = publish_review_file(session, event)

            return publish_review_task
            
            
        elif function_request == "publish_task_status_update":

            update_tsk_status = update_task_status(session, event)
            return update_tsk_status

        elif function_request == "publish_group_status_update":

            update_tsk_status_grp = update_task_status_group(session, event)
            return update_tsk_status_grp
            

        elif function_request == "check_teams_container":

            check_container = check_teams_container(session, event)

           
            return check_container


        elif function_request == "check_multicomp_container":

            check_multi_container = check_multicomp_container(session, event)

            return check_multi_container


    
    else:
        return None
    
# ASSIGNING ICON
def icon_from_filetype(asset_type, isTemplate=False):

    review_types = ['.mov', '.mp4']
    threed_types = ['.c4d', '.ma', '.3ds', '.max']
    graphic_types = ['.png', '.jpg', '.jpeg', '.tiff', '.svg']

    
    if asset_type == '.aep':

        if isTemplate == False:
            if platform.system() == "Windows":
                thumb = 'T:/public/Sports_design/AE_Scripts/_ftrack/icons/adobe/ae_prj_icon.png'
            else:
                thumb = '/Volumes/tscreative/public/Sports_design/AE_Scripts/_ftrack/icons/adobe/ae_prj_icon.png'
            return thumb
        else:
            if platform.system() == "Windows":
                thumb = 'T:/public/Sports_design/AE_Scripts/_ftrack/icons/adobe/ae_template_icon.png'
            else:
                thumb = '/Volumes/tscreative/public/Sports_design/AE_Scripts/_ftrack/icons/adobe/ae_template_icon.png'
            return thumb
        
    elif asset_type == '.psd':

        if platform.system() == "Windows":
            thumb = 'T:/public/Sports_design/AE_Scripts/_ftrack/icons/adobe/psd_prj_icon.png'
        else:
            thumb = '/Volumes/tscreative/public/Sports_design/AE_Scripts/_ftrack/icons/adobe/psd_prj_icon.png'
        return thumb
    
    elif asset_type == '.ai':
        if platform.system() == "Windows":
            thumb = 'T:/public/Sports_design/AE_Scripts/_ftrack/icons/adobe/ai_prj_icon.png'
        else:
            thumb = '/Volumes/tscreative/public/Sports_design/AE_Scripts/_ftrack/icons/adobe/ai_prj_icon.png'
        return thumb
    
    elif asset_type in graphic_types:
        
        return None
    
    else:
        return None
    
# PUBLISHING AE FILE
def publish_ae_file(session, event):
    logger.info(event['data']['ae_info'])

    # ----------------------------
    # Extract inputs
    # ----------------------------
    ae = event['data']['ae_info']
    theprojectid     = ae['PROJ_ID']
    thefilepath      = ae['FILEPATH']
    teamobjname      = ae['TEAMOBJNAME']
    foldername       = ae['FOLDERNAME']
    folderid         = ae['FOLDERID']

    thetaskid        = ae['TASK_ID']
    theassname       = ae['ASSET_NAME']
    theasstype       = ae['ASSET_TYPE']      # display/type name used in asset name
    theassshort      = ae['ASSET_SHORT']     # AssetType.short
    thetempfilepath  = ae['AETEMPPATH']
    thelocname       = ae['LOC_NAME']

    hasteamobj       = ae['USESTEAMSOBJ']
    teamobjid        = ae['TEAMOBJID']
    taskContainerName= ae['TEAMSCONTAINERTASK']

    hasmulticompobj  = ae['USESMULTICOMPOBJ']
    multicompobjid   = ae['MULTICOMPOBJID']

    siblings         = ae['SIBLINGTASKS']
    aetaskname       = ae['TASKNAME']

    statuschange     = ae['STATUSHASCHANGED']
    prjstatus        = ae['STATUSTEXT']
    usrdesc          = ae['USRDESCRIPTION']
    templatetask     = ae['TEMPLATETASK']
    templateid       = ae['TEMPLATEID']

    finalversnum     = ae.get('VERSION_NUM')
    if finalversnum is not None:
        try:
            finalversnum = int(finalversnum)
        except Exception:
            finalversnum = None

    try:
        # ----------------------------
        # Location
        # ----------------------------
        studiolocation = session.ensure('Location', {'name': thelocname})

        # ----------------------------
        # Resolve the task to publish on
        # ----------------------------
        teamsContainerId = None
        if hasteamobj:
            getTaskContId = session.query(
                'Task where name is "{n}" and parent.id is "{pid}"'
                .format(n=taskContainerName, pid=teamobjid)
            ).first()
            if getTaskContId:
                teamsContainerId = getTaskContId['id']

        if hasmulticompobj:
            getTaskContId = session.query(
                'Task where name is "{n}" and parent.id is "{pid}"'
                .format(n=taskContainerName, pid=multicompobjid)
            ).first()
            if getTaskContId:
                teamsContainerId = getTaskContId['id']

        if templatetask:
            task = session.get('Task', templateid)
        else:
            if hasteamobj or hasmulticompobj:
                task = session.get('Task', teamsContainerId)
            else:
                task = session.get('Task', thetaskid)

        asset_parent_object = session.get('TypedContext', task['parent']['id'])
        asset_parent_id     = task['parent']['id']

        # ----------------------------
        # AssetType & canonical Asset name
        # ----------------------------
        asset_type = session.query('AssetType where short is "{0}"'.format(theassshort)).one()

        # IMPORTANT: keep this in lockstep with your Structure logic
        # so that lookups find the exact same asset name the Structure expects.
        asset_name = f'{theassname}_{theasstype}'

        logger.info('Canonical asset name: %s  (type.short=%s)', asset_name, theassshort)

        # ----------------------------
        # Robust Asset lookup / create
        # unique key = (type_id, name, parent/context)
        # ----------------------------
        asset = session.query(
            'Asset where name is "{n}" and type.id is "{t}" and parent.id is "{p}"'
            .format(n=asset_name, t=asset_type['id'], p=asset_parent_id)
        ).first()

        if not asset:
            logger.info("Creating new Asset %r under parent %s", asset_name, asset_parent_id)
            asset = session.create('Asset', {
                'name': asset_name,
                'type': asset_type,
                'parent': asset_parent_object
            })
            try:
                session.commit()
            except Exception as e:
                # Another process may have created it in between → re-query
                logger.warning("Asset commit raced (%s). Re-querying existing asset.", e)
                session.rollback()
                asset = session.query(
                    'Asset where name is "{n}" and type.id is "{t}" and parent.id is "{p}"'
                    .format(n=asset_name, t=asset_type['id'], p=asset_parent_id)
                ).one()

        # ----------------------------
        # Version number: by ASSET, not by (task,type)
        # ----------------------------
        if finalversnum is None:
            last = session.query(
                'AssetVersion where asset.id is "{aid}" order by version descending'
                .format(aid=asset['id'])
            ).first()
            next_version = (last['version'] if last else 0) + 1
        else:
            next_version = finalversnum

        totVersFormatted = 'v{0:03d}'.format(next_version)
        new_assetname    = f'{theassname}_{totVersFormatted}'
        logger.info('Publishing version=%s  label=%s', next_version, new_assetname)

        # ----------------------------
        # Create AssetVersion
        # ----------------------------
        asset_version = session.create('AssetVersion', {
            'asset': asset,
            'task' : task,
            'version': next_version
        })

        # ----------------------------
        # Thumbnail logic (as you had)
        # ----------------------------
        tskthumbattr = task['custom_attributes']['hasRevThumb']
        if templatetask:
            thmb = icon_from_filetype('.aep', isTemplate=True)
            asset_version.create_thumbnail(thmb)
        else:
            if not tskthumbattr:
                thmb = icon_from_filetype('.aep', isTemplate=False)
                asset_version.create_thumbnail(thmb)

        # Also set when in teams container
        # (if you truly want unconditional, keep it; otherwise consider guarding)
        # if task['id'] == teamsContainerId:
        #     thmb = icon_from_filetype('.aep', isTemplate=False)
        #     asset_version.create_thumbnail(thmb)

        session.commit()

        # ----------------------------
        # Propagate group thumbnail to sibling tasks (use !=)
        # ----------------------------
        grpthumbid = asset_version['thumbnail_id']
        matching_tasks = []

        if hasteamobj and not templatetask:
            for item in siblings:
                if item[0] != aetaskname:
                    sib_task = session.get('Task', item[1])
                    matching_tasks.append(sib_task)

            for thetask in matching_tasks:
                subthumbattr = thetask['custom_attributes']['hasRevThumb']
                if subthumbattr is False:
                    thetask['thumbnail_id'] = grpthumbid
            session.commit()

        if hasmulticompobj and not templatetask:
            matching_tasks = []
            for item in siblings:
                if item[0] != aetaskname:
                    sib_task = session.get('Task', item[1])
                    matching_tasks.append(sib_task)

            for thetask in matching_tasks:
                subthumbattr = thetask['custom_attributes']['hasRevThumb']
                if subthumbattr is False:
                    thetask['thumbnail_id'] = grpthumbid
            session.commit()

        # ----------------------------
        # Create component in target location
        # ----------------------------
        component = asset_version.create_component(
            thetempfilepath,
            data={'name': new_assetname},
            location=studiolocation
        )
        session.commit()
        
         # ----------------------------
        # Optional: update status (don’t block publish)
        # ----------------------------
        if statuschange and isinstance(prjstatus, str) and prjstatus.strip():
            safe_update_task_status(session, task['id'], prjstatus, commit=True, logger=logger)

        resPath = studiolocation.get_filesystem_path(component)
        logger.info('Component path: %s', resPath)


        # ----------------------------
        # Optional: update description
        # ----------------------------
        if isinstance(usrdesc, str) and usrdesc.strip():
            task['description'] = usrdesc
            session.commit()

        # ----------------------------
        # Success note
        # ----------------------------
        from datetime import datetime
        formatted_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        currusername = session.api_user
        theuser = session.query('User where username is "{0}"'.format(currusername)).one()
        notebase = 'AE PUBLISH SUCCESSFUL: Version {0} on {1} by {2}'.format(next_version, formatted_date, currusername)
        task.create_note(notebase, author=theuser)
        session.commit()

        return {"success": True, "msg": "AE Published!"}

    except Exception as e:
        logger.info('An error occurred while publishing the After Effects file: %s', str(e))
        session.rollback()

        # Failure note (best effort)
        from datetime import datetime
        formatted_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            task = session.query('Task where id is "{0}"'.format(thetaskid)).first()
            if task:
                currusername = session.api_user
                theuser = session.query('User where username is "{0}"'.format(currusername)).one()
                notebase = 'AE PUBLISH FAILED: Version {0} on {1} by {2} with error {3}'.format(
                    finalversnum if finalversnum is not None else 'n/a',
                    formatted_date, currusername, str(e)
                )
                task.create_note(notebase, author=theuser)
                session.commit()
        except Exception:
            session.rollback()

        return {"success": False, "msg": str(e)}


# PUBLISHING AE FILE
def publish_global_template_file(session, event):
    session.reset()

    # ----------------------------
    # Extract inputs
    # ----------------------------
    ae = event['data']['ae_info']
    theprojectid     = ae['PROJ_ID']
    thefilepath      = ae['FILEPATH']
    thetaskid        = ae['TASK_ID']
    theassname       = ae['ASSET_NAME']
    theasstype       = ae['ASSET_TYPE']      # display/type name used in asset name
    theassshort      = ae['ASSET_SHORT']            # AssetType.short
    thetempfilepath  = ae['AETEMPPATH']
    thelocname       = ae['LOC_NAME']
    aetaskname       = ae['TASKNAME']
    templatetask     = ae['TEMPLATETASK']
    

    finalversnum     = ae.get('VERSION_NUM')
    if finalversnum is not None:
        try:
            finalversnum = int(finalversnum)
        except Exception:
            finalversnum = None

    try:
        # ----------------------------
        # Location
        # ----------------------------
        studiolocation = session.ensure('Location', {'name': thelocname})

        # ----------------------------
        # Resolve the task to publish on
        # ----------------------------
        
        task = session.get('Task', thetaskid)
        asset_parent_object = session.get('TypedContext', task['parent']['id'])
        asset_parent_id     = task['parent']['id']

        # ----------------------------
        # AssetType & canonical Asset name
        # ----------------------------
        asset_type = session.query('AssetType where short is "{0}"'.format(theassshort)).one()

        # IMPORTANT: keep this in lockstep with your Structure logic
        # so that lookups find the exact same asset name the Structure expects.
        asset_name = f'{theassname}_{theasstype}'

        logger.info('Canonical asset name: %s  (type.short=%s)', asset_name, theassshort)

        # ----------------------------
        # Robust Asset lookup / create
        # unique key = (type_id, name, parent/context)
        # ----------------------------
        asset = session.query(
            'Asset where name is "{n}" and type.id is "{t}" and parent.id is "{p}"'
            .format(n=asset_name, t=asset_type['id'], p=asset_parent_id)
        ).first()

        if not asset:
            logger.info("Creating new Asset %r under parent %s", asset_name, asset_parent_id)
            asset = session.create('Asset', {
                'name': asset_name,
                'type': asset_type,
                'parent': asset_parent_object
            })
            try:
                session.commit()
            except Exception as e:
                # Another process may have created it in between → re-query
                logger.warning("Asset commit raced (%s). Re-querying existing asset.", e)
                session.rollback()
                asset = session.query(
                    'Asset where name is "{n}" and type.id is "{t}" and parent.id is "{p}"'
                    .format(n=asset_name, t=asset_type['id'], p=asset_parent_id)
                ).one()

        # ----------------------------
        # Version number: by ASSET, not by (task,type)
        # ----------------------------
        if finalversnum is None:
            last = session.query(
                'AssetVersion where asset.id is "{aid}" order by version descending'
                .format(aid=asset['id'])
            ).first()
            next_version = (last['version'] if last else 0) + 1
        else:
            next_version = finalversnum

        totVersFormatted = 'v{0:03d}'.format(next_version)
        new_assetname    = f'{theassname}_{totVersFormatted}'
        logger.info('Publishing version=%s  label=%s', next_version, new_assetname)

        # ----------------------------
        # Create AssetVersion
        # ----------------------------
        asset_version = session.create('AssetVersion', {
            'asset': asset,
            'task' : task,
            'version': next_version
        })

        # ----------------------------
        # Thumbnail logic (as you had)
        # ----------------------------
        tskthumbattr = task['custom_attributes']['hasRevThumb']
        if templatetask:
            thmb = icon_from_filetype('.aep', isTemplate=True)
            asset_version.create_thumbnail(thmb)
        else:
            if not tskthumbattr:
                thmb = icon_from_filetype('.aep', isTemplate=False)
                asset_version.create_thumbnail(thmb)

        # Also set when in teams container
        # (if you truly want unconditional, keep it; otherwise consider guarding)
        # if task['id'] == teamsContainerId:
        #     thmb = icon_from_filetype('.aep', isTemplate=False)
        #     asset_version.create_thumbnail(thmb)

        session.commit()

        # ----------------------------
        # Propagate group thumbnail to sibling tasks (use !=)
        # ----------------------------
        grpthumbid = asset_version['thumbnail_id']
        

        # ----------------------------
        # Create component in target location
        # ----------------------------
        component = asset_version.create_component(
            thetempfilepath,
            data={'name': new_assetname},
            location=studiolocation
        )
        session.commit()

        resPath = studiolocation.get_filesystem_path(component)
        logger.info('Component path: %s', resPath)


        

        # ----------------------------
        # Success note
        # ----------------------------
        from datetime import datetime
        formatted_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        currusername = session.api_user
        theuser = session.query('User where username is "{0}"'.format(currusername)).one()
        notebase = 'GLOBAL AE TEMPLATE PUBLISH SUCCESSFUL: Version {0} on {1} by {2}'.format(next_version, formatted_date, currusername)
        task.create_note(notebase, author=theuser)
        session.commit()

        return {"success": True, "msg": "AE Global Template Published!"}

    except Exception as e:
        logger.info('An error occurred while publishing the After Effects file: %s', str(e))
        session.rollback()

        # Failure note (best effort)
        from datetime import datetime
        formatted_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            task = session.query('Task where id is "{0}"'.format(thetaskid)).first()
            if task:
                currusername = session.api_user
                theuser = session.query('User where username is "{0}"'.format(currusername)).one()
                notebase = 'GLOBAL AE TEMPLATE PUBLISH FAILED: Version {0} on {1} by {2} with error {3}'.format(
                    finalversnum if finalversnum is not None else 'n/a',
                    formatted_date, currusername, str(e)
                )
                task.create_note(notebase, author=theuser)
                session.commit()
        except Exception:
            session.rollback()

        return {"success": False, "msg": str(e)}


def safe_update_task_status(session, task_id, desired_name, *, commit=True, logger=None):
    """Set task status only if a matching Task status exists; isolate commit."""
    if not desired_name or not str(desired_name).strip():
        return False

    desired_norm = str(desired_name).strip().lower()

    # Load task once
    task = session.get('Task', task_id)
    if task is None:
        if logger: logger.warning("safe_update_task_status: Task %s not found.", task_id)
        return False

    # Try to use project-scoped Task statuses first (if available),
    # else fall back to all Task statuses.
    candidates = []
    try:
        # Some schemas expose project-configured statuses via Status + project filter.
        # If this query returns empty on your schema, we fall back below.
        candidates = session.query(
            'Status where type is "Task" and project.id is "{pid}"'
            .format(pid=task['project']['id'])
        ).all()
    except Exception:
        candidates = []

    if not candidates:
        # Fallback: all Task statuses (may include ones not usable on this project)
        candidates = session.query('Status where type is "Task"').all()

    target = next((s for s in candidates if (s['name'] or '').strip().lower() == desired_norm), None)
    if not target:
        if logger:
            avail = ", ".join(sorted({(s['name'] or '').strip() for s in candidates}))
            logger.warning("No Task status named %r (case-insensitive). Available: [%s]. Skipping.",
                           desired_name, avail)
        return False

    # If already in that status, nothing to do.
    if (task.get('status') or {}).get('id') == target['id']:
        return True

    try:
        task['status'] = target
        if commit:
            session.commit()
        return True
    except Exception as e:
        session.rollback()
        if logger:
            logger.warning("Status change to %r on Task %s failed (non-fatal): %s",
                           target['name'], task_id, e)
        return False


# PUBLISHING AE RENDER (safer filtering, quoted strings, id-scoped lookups)
def publish_review_file(session, event):
    from datetime import datetime
    import logging
    logger = logging.getLogger(__name__)

    session.reset()

    # EXTRACTING INFO
    theprojectid      = event['data']['ae_info']['PROJ_ID']
    thetaskid         = event['data']['ae_info']['TASK_ID']
    theassname        = event['data']['ae_info']['ASSET_NAME']
    theassshort       = event['data']['ae_info']['ASSET_SHORT']  # expected "review"
    publishfilepath   = event['data']['ae_info']['FILEPATH']
    thelocname        = 'studio.central-storage-location'

    hasteamobj        = event['data']['ae_info']['USESTEAMSOBJ']
    hasmulticompobj   = event['data']['ae_info']['USESMULTICOMPOBJ']

    containertaskname = event['data']['ae_info']['TEAMSCONTAINERNAME']
    teamobjid         = event['data']['ae_info']['TEAMOBJID']
    multicompobjid    = event['data']['ae_info']['MULTICOMPOBJID']

    aepublishver      = event['data']['ae_info']['AEPUBLISHVER']
    aepublishfile     = event['data']['ae_info']['AEPUBLISHFILE']

    try:
        finalversnum = event['data']['ae_info'].get('VERSION_NUM')
        finalversnum = int(finalversnum) if finalversnum is not None else None
    except Exception:
        finalversnum = None

    try:
        # ---- Location (avoid ensure() multiple) ----
        locs = session.query('Location where name is "{0}"'.format(thelocname)).all()
        if not locs:
            # create if truly missing
            studiolocation = session.create('Location', {'name': thelocname})
            session.commit()
        else:
            if len(locs) > 1:
                logger.warning('Multiple Locations named %s. Using the first: %s', thelocname, [l['id'] for l in locs])
            studiolocation = locs[0]

        # ---- Task and parent ----
        task = session.query('Task where id is "{0}"'.format(thetaskid)).first()
        if not task:
            raise RuntimeError('Task not found: {0}'.format(thetaskid))

        asset_parent_object = session.get('TypedContext', task['parent']['id'])
        asset_parent_id     = task['parent']['id']

        # ---- AssetType: review ----
        atypes = session.query('AssetType where short is "review"').all()
        if not atypes:
            raise RuntimeError('AssetType short="review" not found')
        if len(atypes) > 1:
            logger.warning('Multiple AssetType short="review" found. Using first.')
        asset_type = atypes[0]

        # ---- Ensure/find the specific Asset (Review bucket under this parent) ----
        assetobjname = theassname + "_Review"
        asset = session.query(
            'Asset where name is "{n}" and type.short is "{t}" and parent.id is "{p}"'
            .format(n=assetobjname, t=theassshort, p=asset_parent_id)
        ).first()

        if not asset:
            logger.info("Creating new Asset: %s (type=%s parent=%s)", assetobjname, theassshort, asset_parent_id)
            asset = session.create('Asset', {
                'name': assetobjname,
                'type': asset_type,
                'parent': asset_parent_object
            })
            session.commit()

        # ---- Compute version number by asset.id, not by type on the whole task ----
        if finalversnum is None:
            existing_versions = session.query(
                'AssetVersion where asset.id is "{aid}"'.format(aid=asset['id'])
            ).all()
            finalversnum = len(existing_versions) + 1

        totVersFormatted = 'v{0:03d}'.format(finalversnum)
        new_assetname    = theassname + '_' + totVersFormatted
        logger.info("Publishing version %s of asset %s", finalversnum, assetobjname)

        # ---- Create AssetVersion ----
        asset_version = session.create('AssetVersion', {
            'asset': asset,
            'task': task,
        })
        asset_version['version'] = finalversnum
        session.commit()

        # ---- Attach component at the studio location ----
        component = asset_version.create_component(
            publishfilepath,
            data={'name': new_assetname},
            location=studiolocation
        )
        session.commit()

        resPath = studiolocation.get_filesystem_path(component)
        encode_info = encode_item_async(asset_version['id'], resPath)
        logger.info("Encode scheduled: %s", encode_info)

        # ---- Update status ----
        update_render_status(session, task['id'], 'Pending Review')
        session.commit()

        # ---- Link back to AE publish version (if given) ----
        aefileverresid = None
        if aepublishver is not None and aepublishfile is not None:
            prjshort = "aep"

            # Resolve the container task ID robustly
            container_task_id = None
            if hasteamobj:
                # task under team container
                ctasks = session.query(
                    'Task where name is "{name}" and project.id is "{prj}" and parent.id is "{parent}"'
                    .format(name=containertaskname, prj=theprojectid, parent=teamobjid)
                ).all()
            elif hasmulticompobj:
                # task under multicomp container
                ctasks = session.query(
                    'Task where name is "{name}" and project.id is "{prj}" and parent.id is "{parent}"'
                    .format(name=containertaskname, prj=theprojectid, parent=multicompobjid)
                ).all()
            else:
                # same task
                ctasks = [task]

            if not ctasks:
                logger.warning('No container task resolved for AE publish link (name=%s)', containertaskname)
            else:
                if len(ctasks) > 1:
                    logger.warning('Multiple tasks resolved for container name "%s"; using first.', containertaskname)
                container_task_id = ctasks[0]['id']

            if container_task_id:
                vers_candidates = session.query(
                    'AssetVersion where task.id is "{tid}" and asset.type.short is "{short}" and version is {ver}'
                    .format(tid=container_task_id, short=prjshort, ver=int(aepublishver))
                ).all()
                if len(vers_candidates) == 1:
                    aefileassvers = vers_candidates[0]
                    # dig out the resource_identifier from its components/locations
                    for cmpo in aefileassvers['components']:
                        for locs in cmpo['component_locations']:
                            rid = locs.get('resource_identifier')
                            if rid:
                                aefileverresid = rid
                                break
                        if aefileverresid:
                            break
                elif len(vers_candidates) == 0:
                    logger.warning('No AE AssetVersion found for task %s v%s', container_task_id, aepublishver)
                else:
                    logger.warning('Multiple AE AssetVersions found for task %s v%s; pick one by additional scoping.',
                                   container_task_id, aepublishver)

        # ---- Set metadata if we found the AE file version ----
        if aefileverresid:
            asset_version['metadata']['CreatedByAEFile'] = aefileverresid

        # ---- Update custom attributes ----
        task['custom_attributes']['hasRevThumb'] = True

        # ---- Success note ----
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        currusername = session.api_user
        users = session.query('User where username is "{0}"'.format(currusername)).all()
        if not users:
            logger.warning('Author user not found for username %s', currusername)
            theuser = None
        else:
            if len(users) > 1:
                logger.warning('Multiple Users with username %s; using first.', currusername)
            theuser = users[0]

        notebase = 'REVIEW PUBLISH SUCCESSFUL: Version {0} on {1} by {2}'.format(finalversnum, now, currusername)
        task.create_note(notebase, author=theuser)
        session.commit()

        return {"success": True, "msg": "Review Published!"}

    except Exception as e:
        logger.info('An error occurred while publishing the Review file: %s', str(e))
        session.rollback()

        # Failure note
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        task = session.query('Task where id is "{0}"'.format(thetaskid)).first()
        currusername = session.api_user
        users = session.query('User where username is "{0}"'.format(currusername)).all()
        theuser = users[0] if users else None
        notebase = 'REVIEW PUBLISH FAILED: Version {0} on {1} by {2} with error {3}'.format(
            finalversnum, now, currusername, str(e)
        )
        if task:
            task.create_note(notebase, author=theuser)
            session.commit()

        return {"success": False, "msg": str(e)}


# # PUBLISHING AE RENDER
# def publish_review_file(session, event):

#     session.reset()
#     # EXTRACTING INFO
#     theprojectid = event['data']['ae_info']['PROJ_ID']

#     teamobjname = event['data']['ae_info']['TEAMOBJNAME']
#     teamobjid = event['data']['ae_info']['TEAMOBJID']

#     multicompobjname = event['data']['ae_info']['MULTICOMPOBJNAME']
#     multicompobjid = event['data']['ae_info']['MULTICOMPOBJID']

#     foldername = event['data']['ae_info']['FOLDERNAME']
#     folderid = event['data']['ae_info']['FOLDERID']
#     siblings = event['data']['ae_info']['SIBLINGTASKS']
#     reviewtaskname = event['data']['ae_info']['TASKNAME']

#     thetaskid = event['data']['ae_info']['TASK_ID']
#     theassname = event['data']['ae_info']['ASSET_NAME']
#     theassshort = event['data']['ae_info']['ASSET_SHORT']
#     publishfilepath = event['data']['ae_info']['FILEPATH']
#     thelocname = 'studio.central-storage-location';

#     hasteamobj = event['data']['ae_info']['USESTEAMSOBJ']
#     hasmulticompobj = event['data']['ae_info']['USESMULTICOMPOBJ']

    
#     containertaskname = event['data']['ae_info']['TEAMSCONTAINERNAME']
#     aepublishver = event['data']['ae_info']['AEPUBLISHVER']
#     aepublishfile = event['data']['ae_info']['AEPUBLISHFILE']

#     try:
#         finalversnum = event['data']['ae_info']['VERSION_NUM']
#     except:
#         finalversnum = None
    

#     if finalversnum is not None:
#         finalversnum = int(finalversnum)
    
#     try:

#         studiolocation = session.ensure('Location', {'name': thelocname})

#         task = session.query('Task where id is {0}'.format(thetaskid)).first()
        
#         assetobjname = theassname + "_Review";
        
#         asset_parent = task['parent']
#         asset_parent_object = session.get('TypedContext', task['parent']['id'])
#         asset_parent_id = task['parent']['id']
#         asset_type = session.query('AssetType where short is "review"').one()
#         logger.info(asset_type)

#         # QUERY ASSETVERSION TO GET MOST CURRENT NUMBER
#         getReviewVers = session.query('AssetVersion where task.id is {0} and asset.type.short is {1}'.format(thetaskid, theassshort)).all()
        
#         #EXTRACTING VERSION NUMBER AND FORMATTING FOR NAME

#         if finalversnum is None:
#             currRevVers = len(getReviewVers)
#             finalversnum = currRevVers + 1

#         totVersFormatted = 'v{0:03d}'.format(finalversnum)

#         #APPENDING ASSET NUMBER TO NAME
#         new_assetname = theassname + '_' + totVersFormatted
#         logger.info(new_assetname)


#         asset = session.query(
#             'Asset where name is "{n}" and type.short is "{t}" and parent.id is "{p}"'
#             .format(n=assetobjname, t=theassshort, p=asset_parent_id)
#         ).first()


#         # asset = session.query('Asset where parent.id is {0} and name is {1}'.format(asset_parent_id, assetobjname)).first()
#         logger.info(asset)
        
#         if not asset:

#             logger.info("Creating New Asset")
#             # CREATING ASSET
#             asset = session.create('Asset', {
#                 'name': assetobjname,
#                 'type': asset_type,
#                 'parent': asset_parent_object
#             })

        
#         # CREATING ASSET VERSION
#         asset_version = session.create('AssetVersion', {
#             'asset': asset,
#             'task': task,
#         })

#         #FORCING VERSION NUMBER
#         asset_version['version'] = finalversnum

#         # thmb = icon_from_filetype('.aep', isTemplate=False)
#         # asset_version.create_thumbnail(thmb)

#         session.commit()

#         # grpthumbid = asset_version['thumbnail_id']

        
#         #CREATING COMPONENT NAME
#         component = asset_version.create_component(
#             publishfilepath,
#             data={'name': new_assetname},
#             location=studiolocation
#         )

#         session.commit()

#         resPath = studiolocation.get_filesystem_path(component)
        
#         # MAKE WEB PLAYABLE VERSION
#         encode_info = encode_item_async(asset_version['id'], resPath)
#         logger.info("Encode scheduled: %s", encode_info)


#         # UPDATE STATUS
#         update_render_status(session, task['id'], 'Pending Review')
#         session.commit()

#         # GET ASSOCIATED AE PUBLISH VERSION
#         aefileverresid = None
#         if aepublishver is not None:
#             if aepublishfile is not None:

#                 if hasteamobj == True:
#                     prjshort = "aep";
#                     aefileassvers = session.query('AssetVersion where task.name is {0} and asset.type.short is {1} and version is {2}'.format(containertaskname, prjshort, aepublishver)).one()
#                     logger.info(aefileassvers)
#                     for cmpo in aefileassvers['components']:
#                         for locs in cmpo['component_locations']:
#                             logger.info(locs['resource_identifier'])
#                             aefileverresid = locs['resource_identifier']

#                 elif hasmulticompobj == True:
#                     prjshort = "aep";
#                     aefileassvers = session.query('AssetVersion where task.name is {0} and asset.type.short is {1} and version is {2}'.format(containertaskname, prjshort, aepublishver)).one()
#                     logger.info(aefileassvers)
#                     for cmpo in aefileassvers['components']:
#                         for locs in cmpo['component_locations']:
#                             logger.info(locs['resource_identifier'])
#                             aefileverresid = locs['resource_identifier']

#                 else:
#                     prjshort = "aep";
#                     aefileassvers = session.query('AssetVersion where task.id is {0} and asset.type.short is {1} and version is {2}'.format(thetaskid, prjshort, aepublishver)).one()
#                     logger.info(aefileassvers)
#                     for cmpo in aefileassvers['components']:
#                         for locs in cmpo['component_locations']:
#                             logger.info(locs['resource_identifier'])
#                             aefileverresid = locs['resource_identifier']


#         # SETTING METADATA TO ASSET VERSION
#         if aefileverresid is not None:
#             asset_version['metadata']['CreatedByAEFile'] = aefileverresid

#         # UPDATE CUSTOM ATTRIBUTES
#         task['custom_attributes']['hasRevThumb'] = True


#         #PUBLISH SUCCESS NOTES TO TASK 
#         # GETTING DATE AND TIME
#         now = datetime.now()

#         # Format the datetime object as a string
#         formatted_date = now.strftime("%Y-%m-%d %H:%M:%S")

#         #PUBLISH NOTEITEM TO TASK
#         currusername = session.api_user
#         theuser = session.query('User where username is "{0}"'.format(currusername)).one()
#         usr = currusername

#         # Create note using the helper method
        
#         notebase = 'REVIEW PUBLISH SUCCESSFUL: Version {0} on {1} by {2}'.format(finalversnum,formatted_date,usr)
#         note = task.create_note(notebase, author=theuser)

#         session.commit()
      
#         return {"success": True, "msg": "Review Published!"}

#     except Exception as e:

#         logger.info(
#             f'An error occurred while publishing the Review file: {str(e)}'
#         )
        

#         session.rollback()

#         #PUBLISH FAIL NOTES TO TASK
#         # GETTING DATE AND TIME
#         now = datetime.now()

#         # Format the datetime object as a string
#         formatted_date = now.strftime("%Y-%m-%d %H:%M:%S")

#         task = session.query('Task where id is {0}'.format(thetaskid)).first()

#         currusername = session.api_user
#         theuser = session.query('User where username is "{0}"'.format(currusername)).one()
#         usr = currusername

#         # Create note using the helper method.
#         notebase = 'REVIEW PUBLISH FAILED: Version {0} on {1} by {2} with error {3}'.format(
#             finalversnum, formatted_date, usr, str(e)
#         )
        
#         note = task.create_note(notebase, author=theuser)

#         session.commit()

#         return {"success": False, "msg": str(e)}

def monitor_job_status(session, asset_vers, origlen, job):
    
    logger.info(origlen)
    logger.info(f"Asset Version Length is: {origlen}")
    getnewvers = session.query('AssetVersion where id is "{0}"'.format(asset_vers['id'])).one()
    newverslen = len(getnewvers['components'])
    
    while origlen >= newverslen:
        # Poll the job status
        getnewvers = session.query('AssetVersion where id is "{0}"'.format(asset_vers['id'])).one()
        newverslen = len(getnewvers['components'])

        logger.info(f"Asset Version Original Length is: {origlen}")
        logger.info(f"Asset Version New Length is: {len(getnewvers['components'])}")
        
        time.sleep(5)
    logger.info(f"Encoding complete on: {getnewvers['asset']['name']}")
    session.commit()

def encode_item(session, asset_vers, media_path):
    origlen = len(asset_vers['components'])
    job = asset_vers.encode_media(media_path)
    # Start a separate thread to monitor the job status
    threading.Thread(target=monitor_job_status, args=(session, asset_vers, origlen, job,)).start()
    logger.info("Encoding job initiated. Monitoring in separate thread.")
    # Continue with other operations, the monitor thread will handle completion
    return job


def _new_session():
    """Create a fresh ftrack session for background threads.
    Relies on FTRACK_SERVER / FTRACK_API_USER / FTRACK_API_KEY env vars (Connect sets these)."""
    # Avoid connecting an extra event hub in background threads.
    return ftrack_api.Session(auto_connect_event_hub=False)


def encode_item_async(asset_version_id, media_path, poll_seconds=5, timeout_seconds=6*60*60):
    """
    Trigger encode in a background thread and start a background monitor.
    Returns immediately (no Job object, by design).
    """
    def worker():
        try:
            sess = _new_session()
            av = sess.get('AssetVersion', asset_version_id)
            # This call may upload the file first; doing it in the worker avoids blocking the caller.
            job = av.encode_media(media_path)

            # Start monitoring in the SAME background session
            _monitor_job_components(sess, asset_version_id, job, poll_seconds, timeout_seconds)
        except Exception as e:
            logger.exception("Background encode worker failed: %s", e)

    t = threading.Thread(target=worker, daemon=True)
    t.start()
    return {"scheduled": True}


def _monitor_job_components(session, asset_version_id, job, poll_seconds, timeout_seconds):
    """Poll for a new component appearing on the AssetVersion (simple & robust).
       Avoids using the caller's session. No commits needed here."""
    try:
        av = session.get('AssetVersion', asset_version_id)
        orig_len = len(av['components'])
        logger.info("Monitor: starting with %d components for AV %s", orig_len, asset_version_id)

        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            # Optionally also poll job status if present; many setups expose job['status'] or job['state'].
            try:
                job_refreshed = session.get('Job', job['id'])
                jstate = (job_refreshed.get('status') or
                          (job_refreshed.get('state') and job_refreshed['state'].get('name')))
                if jstate:
                    logger.info("Encode job %s status: %s", job['id'], jstate)
            except Exception:
                pass  # job entity may differ per server setup; component count is our primary signal.

            av = session.get('AssetVersion', asset_version_id)
            new_len = len(av['components'])
            logger.info("Monitor: components %d -> %d", orig_len, new_len)
            if new_len > orig_len:
                logger.info("Encoding complete for AV %s", asset_version_id)
                return
            time.sleep(poll_seconds)

        logger.warning("Encode monitor timeout for AV %s after %ss", asset_version_id, timeout_seconds)
    except Exception as e:
        logger.exception("Monitoring failed for AV %s: %s", asset_version_id, e)

def register(session):

    
    '''Subscribe to application launch events on *registry*.'''
    if not isinstance(session, ftrack_api.session.Session):
        return

    handle_discovery_event = functools.partial(
        on_discover_integration, session
    )

    session.event_hub.subscribe(
        'topic=ftrack.connect.application.discover and '
        'data.application.identifier=aftereffects*'
        ' and data.application.version >= 16',
        handle_discovery_event,
        priority=40,
    )

    handle_launch_event = functools.partial(on_launch_integration, session)

    session.event_hub.subscribe(
        'topic=ftrack.connect.application.launch and '
        'data.application.identifier=aftereffects*'
        ' and data.application.version >= 16',
        handle_launch_event,
        priority=40,
    )

    handle_chatterbox_event = functools.partial(on_chatterbox_notification, session)

    session.event_hub.subscribe(
        'topic=custom.chatterbox.chatter',
        handle_chatterbox_event,
        priority=10,
    )



    logger.info(
        'Registered {} integration v{} discovery and launch.'.format(
            NAME, __version__
        )

    
    )

