/*
 ftrack Adobe Premiere framework integration bootstrap

 Copyright (c) 2024 ftrack
*/


function jsx_callback(){
    console.log("ae.jsx loaded");
}

try {
    jsx.evalFile('./ae.jsx', jsx_callback);
} catch (e) {
    error("[INTERNAL ERROR] Failed to load JSX resource "+e+" Details: "+e.stack);
}

function jsx_include_callback(){
    console.log("ae-include loaded");
}

// Load custom extension JSX if exists
try {
    jsx.evalFile('./ae-include.jsx', jsx_include_callback);
} catch (e) {
    console.log("[WARNING] Failed to load JSX include resource "+e+" Details: "+e.stack);
}

// Whitelisted functions and their mappings, add entrypoints from ae.jsx here
window.FTRACK_RPC_FUNCTION_MAPPING = {
    getProjectPath:"getProjectPath",
    saveProject:"saveProject",
    saveProjectAs:"saveProjectAs",
    render:"render",
    openProject:"openProject",
};

window.ftrackInitialiseExtension = function(session, event_manager, remote_integration_session_id) {
    // Do additional initialisations here
};


window.ftrackIntegrationConnected = function() {
    // React upon integration connected
    console.log("SUCCESSFULLY LOADED FTRACK INTEGRATION")
};


