# :coding: utf-8
import logging
import json
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from urllib.parse import quote, urlencode
from typing import Any, Dict, Optional, List, Tuple

import ftrack_api
from ftrack_action_handler.action import BaseAction

# ---------- CONFIG ----------
DATA_PARENT_NAME = '0000_DATA'
TEAMS_TASK_NAME = 'ALL_TEAMS'
STRUCTURE_TASK_NAME = 'MATCHMAKER_STRUCTURE'

WIDGET_URL   = 'https://cobramachete.github.io/Ox-Cart/matchmaker'
WIDGET_TITLE = 'MatchMaker'
WIDGET_WIDTH = 1280
WIDGET_HEIGHT = 800

ALLOWED_TYPES_DISCOVER = ('Production')                # discover gate
ALLOWED_TYPES_LAUNCH   = ('Production')                 # launch gate
# ---------------------------


def _latest_component_and_urls(
    session: ftrack_api.Session,
    task_name: str,
    project_id: str,
    parent_name: str,
    logger: logging.Logger
) -> Tuple[Optional[str], List[str]]:
    """
    Return (component_id, [url, ...]) from the latest AssetVersion of the named task.
    component_id is from the first component on the latest version (common case).
    URLs list may be empty on some deployments/locations.
    """
    try:
        q_task = (
            f'Task where name is "{task_name}" and project_id is "{project_id}" '
            f'and parent.name is "{parent_name}"'
        )
        task = session.query(q_task).first()
        if not task:
            logger.warning(f'No Task found for name="{task_name}" project="{project_id}" parent="{parent_name}"')
            return None, []

        q_ver = f'AssetVersion where task_id is "{task["id"]}" and is_latest_version is True'
        version = session.query(q_ver).first()
        if not version:
            logger.warning(f'No latest AssetVersion on task "{task_name}" ({task["id"]})')
            return None, []

        comps = version.get('components') or []
        if not comps:
            logger.warning(f'No components on latest version for task "{task_name}"')
            return None, []

        comp = comps[0]
        comp_id = comp.get('id')

        comp_locs = comp.get('component_locations') or []
        urls: List[str] = []
        for loc in comp_locs:
            # Some locations expose a direct URL: loc['url']['value']
            url = (((loc or {}).get('url') or {}).get('value'))
            if url:
                urls.append(url)

        if not urls:
            logger.info(f'No direct URLs exposed for "{task_name}" (component_id={comp_id}); '
                        f'client should resolve via API using credentials.')
        return comp_id, urls

    except Exception as e:
        logger.exception(f'Error collecting component/URLs for task "{task_name}": {e}')
        return None, []


def _fetch_json_from_url(url: str, logger: logging.Logger, timeout: float = 15.0) -> Optional[Dict[str, Any]]:
    """Fetch JSON from a URL; return dict or None."""
    try:
        if not (url.startswith('http://') or url.startswith('https://') or url.startswith('file://')):
            logger.warning(f'Unsupported URL scheme for JSON fetch: {url}')
            return None

        req = Request(url, headers={'User-Agent': 'MatchMakerWidgetAction/1.0'})
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
        try:
            return json.loads(raw)
        except json.JSONDecodeError as je:
            logger.warning(f'JSON decode failed for {url}: {je}')
            return None
    except HTTPError as he:
        logger.warning(f'HTTPError fetching {url}: {he.code} {he.reason}')
    except URLError as ue:
        logger.warning(f'URLError fetching {url}: {ue.reason}')
    except Exception as e:
        logger.exception(f'Unexpected error fetching {url}: {e}')
    return None


class MatchMakerWidgetAction(BaseAction):
    identifier = 'tntsports.launchmatchmaker.action'
    label = 'MatchMaker'
    description = 'Structured Matchup Creator and Builder'
    icon = 'https://cobramachete.github.io/ftrack_icons/img/matchmaker_icon.png'

    def __init__(self, session):
        super(MatchMakerWidgetAction, self).__init__(session)
        self.logger = logging.getLogger(__name__)

    # ---- Discover ----
    def discover(self, session, entities, event):
        self.logger.info("Discovering MatchMaker")
        user_id = event.get('source', {}).get('user', {}).get('username')
        curr_user = session.api_user
        self.logger.info(f'Event user: {user_id} / Session user: {curr_user}')

        if user_id != curr_user:
            return False

        selection = (event.get('data') or {}).get('selection') or []
        if len(selection) != 1:
            return False

        entity_id = selection[0].get('entityId')
        if not entity_id:
            return False

        try:
            entity = session.get('TypedContext', entity_id)
            if not entity:
                return False
            obj_type = (entity.get('object_type') or {}).get('name')
            self.logger.info(f'Discover entity: {entity_id} type={obj_type}')
            return obj_type in ALLOWED_TYPES_DISCOVER
        except Exception as e:
            self.logger.warning(f'Error in discover fetching entity: {e}')
            return False

    # ---- Launch ----
    def launch(self, session, entities, event):
        if (event.get('data') or {}).get('actionIdentifier') != self.identifier:
            self.logger.info('Ignored launch event not meant for this action.')
            return

        selection = (event.get('data') or {}).get('selection') or []
        if len(selection) != 1:
            return {'success': False, 'message': 'Select exactly one entity.'}

        entity_id = selection[0].get('entityId')
        if not entity_id:
            return {'success': False, 'message': 'Missing entity id in selection.'}

        try:
            entity = session.get('TypedContext', entity_id)
            if not entity:
                return {'success': False, 'message': 'Failed to resolve entity.'}

            obj_type = (entity.get('object_type') or {}).get('name')
            if obj_type not in ALLOWED_TYPES_LAUNCH:
                return {'success': False, 'message': f'Unsupported type: {obj_type}'}

            project_id = entity.get('project_id')
            if not project_id:
                return {'success': False, 'message': 'Entity missing project_id.'}

            self.logger.info(f'Launching MatchMaker for {entity_id} ({obj_type})')

            # Resolve latest components and any exposed URLs
            teams_comp_id, teams_urls = _latest_component_and_urls(
                session, TEAMS_TASK_NAME, project_id, DATA_PARENT_NAME, self.logger
            )
            struct_comp_id, struct_urls = _latest_component_and_urls(
                session, STRUCTURE_TASK_NAME, project_id, DATA_PARENT_NAME, self.logger
            )

            # Build hash params. Prefer direct URLs when available (CORS may still block in browser).
            params = {
                'entity_id': entity_id or '',
                'project_id': project_id or '',
                'teams_comp': teams_comp_id or '',
                'struct_comp': struct_comp_id or '',
                'teams_url': (teams_urls[0] if teams_urls else ''),
                'structure_url': (struct_urls[0] if struct_urls else '')
            }

            # Log what we're sending (trim long URLs)
            dbg = {k: (v if len(str(v)) < 140 else str(v)[:140] + '…') for k, v in params.items()}
            self.logger.info(f'MatchMaker seed (hash params): {dbg}')

            # Assemble widget URL with hash
            # Use urlencode with doseq=False; safe='' since we want strict encoding.
            hash_str = urlencode(params, doseq=False, safe='')
            seed_url = f'{WIDGET_URL}#{hash_str}'

            response = {
                'success': True,
                'message': 'success',
                'type': 'widget',
                'url': seed_url,
                'title': WIDGET_TITLE,
                'width': WIDGET_WIDTH,
                'height': WIDGET_HEIGHT
            }
            self.logger.info('Returning widget response with hash-seeded URL.')
            return response

        except Exception as e:
            self.logger.exception(f'Error in launch: {e}')
            return {'success': False, 'message': f'Unexpected error: {e}'}


def register(session, **kw):
    if not isinstance(session, ftrack_api.Session):
        return
    action = MatchMakerWidgetAction(session)
    action.register()
    logging.info("MatchMakerWidgetAction registered successfully!")


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    session = ftrack_api.Session(auto_connect_event_hub=True)
    register(session)
    session.event_hub.wait()
